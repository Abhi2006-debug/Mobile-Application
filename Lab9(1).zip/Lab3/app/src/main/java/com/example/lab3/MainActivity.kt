package com.example.lab3

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
// 1. Create the data for your tools
        val toolList = listOf(
            MathTool("Matrix Solver", "#2196F3", MatrixActivity::class.java),
            MathTool("Physics (Optics)", "#4CAF50", PhysicsActivity::class.java),
            MathTool("Unit Converter", "#FF9800", ConverterActivity::class.java),
            MathTool("Scientific Calculator", "#607D8B", ScientificCalculatorActivity::class.java),
            MathTool("Quadratic Solver", "#673AB7", QuadraticActivity::class.java),
            MathTool("Vector Operations", "#009688", VectorActivity::class.java),
            MathTool("Physics Projectile", "#C2189C", ProjectileActivity::class.java),
            MathTool("Geometry Solver", "#C2185B", GalleryActivity::class.java)
        )

  // 2. SETUP THE RECYCLER VIEW AND ADAPTER
       val recyclerView = findViewById<RecyclerView>(R.id.rv_math_tools)

       // Use GridLayoutManager for a Grid (e.g., 2 columns), or LinearLayoutManager for a standard vertical list
        recyclerView.layoutManager = GridLayoutManager(this, 2)

       // Attach the adapter you provided!
       val adapter = MathToolAdapter(toolList)
        recyclerView.adapter = adapter

      // 3. SETUP FAB AND ACTION BOX (AlertDialog)
        val fab = findViewById<FloatingActionButton>(R.id.fab_info)
        fab.setOnClickListener {
            showInfoActionBox()
        }
    }

    // This fulfills the "Action Box" requirement
    private fun showInfoActionBox() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("MathOS Help")
        builder.setMessage("Tap on any card in the grid to open that specific calculator or tool.")

        // The confirmation button
        builder.setPositiveButton("Understood") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.show()
            }
}