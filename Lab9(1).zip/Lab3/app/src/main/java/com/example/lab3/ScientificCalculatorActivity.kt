package com.example.lab3

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class ScientificCalculatorActivity : AppCompatActivity() {

    private lateinit var tvScreen: TextView
    private var firstValue = 0.0
    private var currentOperation = ""
    private var isNewOp = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scientific_calculator)

        tvScreen = findViewById(R.id.tv_screen)

        setupNumberButtons()
        setupOperationButtons()
        setupScientificButtons()
    }

    private fun setupNumberButtons() {
        val numberIds = listOf(
            R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4,
            R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_dot
        )

        val listener = View.OnClickListener { view ->
            val button = view as Button
            if (isNewOp || tvScreen.text == "Error") {
                tvScreen.text = ""
                isNewOp = false
            }
            // Prevent double decimals
            if (button.text == "." && tvScreen.text.contains(".")) {
                return@OnClickListener
            }
            tvScreen.append(button.text)
        }

        for (id in numberIds) {
            findViewById<Button>(id).setOnClickListener(listener)
        }
    }

    private fun setupOperationButtons() {
        val ops = mapOf(
            R.id.btn_add to "+",
            R.id.btn_sub to "-",
            R.id.btn_mul to "*",
            R.id.btn_div to "/",
            R.id.btn_power to "^"
        )

        for ((id, op) in ops) {
            findViewById<Button>(id).setOnClickListener {
                if (tvScreen.text == "Error") return@setOnClickListener
                currentOperation = op
                firstValue = tvScreen.text.toString().toDoubleOrNull() ?: 0.0
                isNewOp = true
            }
        }

        findViewById<Button>(R.id.btn_equal).setOnClickListener {
            val secondText = tvScreen.text.toString()
            if (secondText == "Error" || secondText.isEmpty()) return@setOnClickListener

            val secondValue = secondText.toDouble()
            var result = 0.0
            var error = false

            when (currentOperation) {
                "+" -> result = firstValue + secondValue
                "-" -> result = firstValue - secondValue
                "*" -> result = firstValue * secondValue
                "/" -> {
                    if (secondValue == 0.0) error = true else result = firstValue / secondValue
                }
                "^" -> result = firstValue.pow(secondValue)
            }

            if (error) {
                tvScreen.text = "Error"
            } else {
                tvScreen.text = formatResult(result)
            }
            isNewOp = true
        }

        findViewById<Button>(R.id.btn_clear).setOnClickListener {
            tvScreen.text = "0"
            firstValue = 0.0
            currentOperation = ""
            isNewOp = true
        }
    }

    private fun setupScientificButtons() {
        // --- SIN ---
        findViewById<Button>(R.id.btn_sin).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            // Fix: Round result to handle tiny floating point errors
            val result = sin(Math.toRadians(value))
            tvScreen.text = formatResult(result)
            isNewOp = true
        }

        // --- COS ---
        findViewById<Button>(R.id.btn_cos).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            // Fix: Directly check for 90, 270 to return exactly 0
            if (value % 180.0 == 90.0) {
                tvScreen.text = "0"
            } else {
                val result = cos(Math.toRadians(value))
                tvScreen.text = formatResult(result)
            }
            isNewOp = true
        }

        // --- TAN ---
        findViewById<Button>(R.id.btn_tan).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            // Fix: Tan(90), Tan(270) are undefined
            if ((value - 90) % 180 == 0.0) {
                tvScreen.text = "Error" // Undefined
            } else {
                val result = tan(Math.toRadians(value))
                tvScreen.text = formatResult(result)
            }
            isNewOp = true
        }

        // --- LOG (Base 10) ---
        findViewById<Button>(R.id.btn_log).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value <= 0) {
                tvScreen.text = "Error"
            } else {
                tvScreen.text = formatResult(log10(value))
            }
            isNewOp = true
        }

        // --- LN (Natural Log) ---
        findViewById<Button>(R.id.btn_ln).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value <= 0) {
                tvScreen.text = "Error"
            } else {
                tvScreen.text = formatResult(ln(value))
            }
            isNewOp = true
        }

        // --- SQRT ---
        findViewById<Button>(R.id.btn_sqrt).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value < 0) {
                tvScreen.text = "Error"
            } else {
                tvScreen.text = formatResult(sqrt(value))
            }
            isNewOp = true
        }
    }

    // Helper: Get number safely
    private fun getCurrentValue(): Double? {
        val text = tvScreen.text.toString()
        return if (text == "Error" || text.isEmpty()) null else text.toDouble()
    }

    // Helper: Round to avoid "0.0000000004" and remove ".0" if integer
    private fun formatResult(value: Double): String {
        // 1. Fix Floating Point Precision (e.g. 6.12e-17 becomes 0.0)
        val rounded = (value * 10000000000).roundToInt() / 10000000000.0

        // 2. Remove decimal if it's a whole number (e.g. "5.0" -> "5")
        return if (rounded == rounded.toLong().toDouble()) {
            rounded.toLong().toString()
        } else {
            rounded.toString()
        }
    }
}