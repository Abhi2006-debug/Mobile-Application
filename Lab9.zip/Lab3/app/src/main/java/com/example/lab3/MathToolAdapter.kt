package com.example.lab3

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class MathToolAdapter(private val tools: List<MathTool>) :
    RecyclerView.Adapter<MathToolAdapter.ToolViewHolder>() {

    // This class finds the views inside your item_math_grid.xml
    class ToolViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val toolName: TextView = view.findViewById(R.id.tv_tool_name)
        val card: CardView = view as CardView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToolViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_math_grid, parent, false)
        return ToolViewHolder(view)
    }

    override fun onBindViewHolder(holder: ToolViewHolder, position: Int) {
        val tool = tools[position]

        holder.toolName.text = tool.name
        holder.card.setCardBackgroundColor(tool.colorInt)

        // This handles the click for EVERY item in the list
        holder.itemView.setOnClickListener {
            val intent = Intent(it.context, tool.activityClass)
            it.context.startActivity(intent)
        }
    }

    override fun getItemCount() = tools.size
}