package com.example.lab3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MatrixActivity : AppCompatActivity() {

    // 1. Declare Variables
    private lateinit var etA: EditText
    private lateinit var etB: EditText
    private lateinit var etC: EditText
    private lateinit var etD: EditText
    private lateinit var tvResult: TextView
    private lateinit var btnShare: Button

    // Store result to share later
    private var calculatedValue = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_matrix)

        // 2. Link Views to IDs
        etA = findViewById(R.id.et_a)
        etB = findViewById(R.id.et_b)
        etC = findViewById(R.id.et_c)
        etD = findViewById(R.id.et_d)
        val btnCalc = findViewById<Button>(R.id.btn_calc)
        tvResult = findViewById(R.id.tv_result)
        btnShare = findViewById(R.id.btn_share)

        // 3. Calculate Button Logic
        btnCalc.setOnClickListener {
            if (validateInputs()) {
                // Parse inputs to Double (Decimal numbers)
                val a = etA.text.toString().toDouble()
                val b = etB.text.toString().toDouble()
                val c = etC.text.toString().toDouble()
                val d = etD.text.toString().toDouble()

                // Math Logic: (a*d) - (b*c)
                calculatedValue = (a * d) - (b * c)

                // Display Result
                tvResult.text = "Result: $calculatedValue"

                // Show the Share button
                btnShare.visibility = Button.VISIBLE
            } else {
                Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show()
            }
        }

        // 4. Share Button Logic (Implicit Intent)
        btnShare.setOnClickListener {
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, "Solved with MATHENV! The determinant is: $calculatedValue")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }

    // Helper function to check if boxes are empty
    private fun validateInputs(): Boolean {
        return etA.text.isNotEmpty() && etB.text.isNotEmpty() &&
                etC.text.isNotEmpty() && etD.text.isNotEmpty()
    }
}