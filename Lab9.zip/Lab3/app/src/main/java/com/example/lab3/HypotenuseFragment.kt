package com.example.lab3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.sqrt

class HypotenuseFragment : BaseLifecycleFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_hypotenuse, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etA = view.findViewById<EditText>(R.id.et_a)
        val etB = view.findViewById<EditText>(R.id.et_b)
        val btnCalc = view.findViewById<Button>(R.id.btn_calc_hyp)
        val tvResult = view.findViewById<TextView>(R.id.tv_result)

        btnCalc.setOnClickListener {
            val aStr = etA.text.toString()
            val bStr = etB.text.toString()
            if (aStr.isNotEmpty() && bStr.isNotEmpty()) {
                val c = sqrt((aStr.toDouble() * aStr.toDouble()) + (bStr.toDouble() * bStr.toDouble()))
                tvResult.text = "Hypotenuse: %.2f".format(c)
            }
        }
    }
}