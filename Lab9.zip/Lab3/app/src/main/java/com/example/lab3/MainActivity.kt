package com.example.lab3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
// 1. Create the data for your tools
        val toolList = listOf(
            MathTool("Matrix Solver", "#2196F3", MatrixActivity::class.java),
            MathTool("Physics (Optics)", "#4CAF50", PhysicsActivity::class.java),
            MathTool("Unit Converter", "#FF9800", ConverterActivity::class.java),
            MathTool("Scientific Calculator", "#607D8B", ScientificCalculatorActivity::class.java),
            MathTool("Quadratic Solver", "#673AB7", QuadraticActivity::class.java),
            MathTool("Vector Operations", "#009688", VectorActivity::class.java),
            MathTool("Physics Projectile", "#C2189C", ProjectileActivity::class.java),
            MathTool("Geometry Solver", "#C2185B", GalleryActivity::class.java)
        )

// 2. Setup the RecyclerView
        val recyclerView =
            findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.rv_math_tools)
        recyclerView.layoutManager =
            androidx.recyclerview.widget.GridLayoutManager(this, 2) // 2 columns
        recyclerView.adapter = MathToolAdapter(toolList)
    }
        // 1. Inflate the menu

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_options_main, menu)
        return true
    }

    // 2. Handle clicks
    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_about -> {
                Toast.makeText(this, "MathOS v1.0\nCreated by You", Toast.LENGTH_LONG).show()
                true
            }
            R.id.action_exit -> {
                finish() // Closes the app
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}