package com.example.lab3

import android.graphics.Color

data class MathTool(
    val name: String,
    val colorString: String,
    val activityClass: Class<*>
) {
    // Helper to convert the string (like "#2196F3") into a real color Int
    val colorInt: Int get() = Color.parseColor(colorString)
}