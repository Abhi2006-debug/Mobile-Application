package com.example.stopwatc // CHANGE THIS to your actual package name

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // 1. Variables to keep track of time and state
    private var seconds = 0
    private var isRunning = false

    // UI Components (lateinit allows us to initialize them later in onCreate)
    private lateinit var timeView: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var resetBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 2. Link the variables to your XML Layout IDs
        timeView = findViewById(R.id.text_view_timer)
        startBtn = findViewById(R.id.button_start)
        stopBtn = findViewById(R.id.button_stop)
        resetBtn = findViewById(R.id.button_reset)

        // 3. Set up Click Listeners (using Kotlin Lambda syntax)

        // START Button
        startBtn.setOnClickListener {
            isRunning = true
        }

        // STOP Button
        stopBtn.setOnClickListener {
            isRunning = false
        }

        // RESET Button
        resetBtn.setOnClickListener {
            isRunning = false
            seconds = 0
        }

        // 4. Start the loop that updates the time
        runTimer()
    }

    // 5. The Core Logic Method
    private fun runTimer() {
        // Looper.getMainLooper() ensures this runs on the main UI thread
        val handler = Handler(Looper.getMainLooper())

        handler.post(object : Runnable {
            override fun run() {
                val hours = seconds / 3600
                val minutes = (seconds % 3600) / 60
                val secs = seconds % 60

                // Format the time string (e.g., "00:05:30")
                val time = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs)

                // Update the TextView
                timeView.text = time

                // Increment seconds if running
                if (isRunning) {
                    seconds++
                }

                // Schedule this same code to run again in 1000ms (1 second)
                handler.postDelayed(this, 1000)
            }
        })
    }
}