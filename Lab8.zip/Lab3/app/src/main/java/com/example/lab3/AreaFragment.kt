package com.example.lab3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.PI

class AreaFragment : BaseLifecycleFragment() { // Inherits logging!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Reuse the layout we made earlier or create a simple one
        val view = inflater.inflate(R.layout.fragment_area, container, false)

        val etRadius = view.findViewById<EditText>(R.id.et_radius)
        val btnCalc = view.findViewById<Button>(R.id.btn_calc_area)
        val tvResult = view.findViewById<TextView>(R.id.tv_result)

        btnCalc.setOnClickListener {
            val rStr = etRadius.text.toString()
            if (rStr.isNotEmpty()) {
                val area = PI * rStr.toDouble() * rStr.toDouble()
                tvResult.text = "Area: %.2f".format(area)
            }
        }
        return view
    }
}