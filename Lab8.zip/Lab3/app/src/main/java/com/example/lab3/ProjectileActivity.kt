package com.example.lab3

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sin

class ProjectileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_projectile)

        // 1. Initialize Inputs (Text Boxes)
        val etVelocity = findViewById<EditText>(R.id.et_velocity)
        val etAngle = findViewById<EditText>(R.id.et_angle)

        // 2. Initialize Radio Group (for Gravity)
        val rgGravity = findViewById<RadioGroup>(R.id.rg_gravity)
        val rbEarth = findViewById<RadioButton>(R.id.rb_earth)
        // Note: We don't strictly need to find rbMoon if we check ID later

        // 3. Initialize Check Boxes
        val cbHeight = findViewById<CheckBox>(R.id.cb_show_height)
        val cbTime = findViewById<CheckBox>(R.id.cb_show_time)

        // 4. Initialize Command Button & Output
        val btnCalculate = findViewById<Button>(R.id.btn_calculate)
        val tvResult = findViewById<TextView>(R.id.tv_result)

        // SET LISTENER
        btnCalculate.setOnClickListener {
            // A. Get Data from Text Boxes
            val vStr = etVelocity.text.toString()
            val aStr = etAngle.text.toString()

            if (vStr.isEmpty() || aStr.isEmpty()) {
                Toast.makeText(this, "Please enter Velocity and Angle", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val v = vStr.toDouble()
            val angleDeg = aStr.toDouble()
            val angleRad = Math.toRadians(angleDeg)

            // B. Check Radio Button for Gravity
            val g = if (rgGravity.checkedRadioButtonId == R.id.rb_earth) {
                9.81 // Earth Gravity
            } else {
                1.62 // Moon Gravity
            }

            // C. Perform Calculations
            // Range formula: R = (v^2 * sin(2*theta)) / g
            val range = (v.pow(2) * sin(2 * angleRad)) / g

            // Build the result string
            val resultBuilder = StringBuilder()
            resultBuilder.append("Planet Gravity: $g m/s²\n")
            resultBuilder.append("--------------------------\n")
            resultBuilder.append("Total Range: %.2f meters\n".format(range))

            // D. Check CheckBox states for extra info
            if (cbHeight.isChecked) {
                // Max Height = (v^2 * sin^2(theta)) / 2g
                val height = (v.pow(2) * sin(angleRad).pow(2)) / (2 * g)
                resultBuilder.append("Max Height:  %.2f meters\n".format(height))
            }

            if (cbTime.isChecked) {
                // Time of Flight = (2 * v * sin(theta)) / g
                val time = (2 * v * sin(angleRad)) / g
                resultBuilder.append("Flight Time: %.2f seconds\n".format(time))
            }

            // Display Final Result
            tvResult.text = resultBuilder.toString()
        }
    }
}