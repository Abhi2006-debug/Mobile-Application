package com.example.lab3

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class GalleryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        // 1. SETUP TAB BUTTONS & FRAGMENTS
        val btnArea = findViewById<Button>(R.id.btn_tab_area)
        val btnHyp = findViewById<Button>(R.id.btn_tab_hyp)

        // Load default fragment
        loadFragment(AreaFragment())

        btnArea.setOnClickListener { loadFragment(AreaFragment()) }
        btnHyp.setOnClickListener { loadFragment(HypotenuseFragment()) }

        // 2. SETUP CONTEXT MENU (Long Press)
        // We will attach the Context Menu to the "Area" button (or you can use tv_header_title)
        registerForContextMenu(btnArea)

        // 3. SETUP POPUP MENU (Click)
        val btnUnits = findViewById<Button>(R.id.btn_units)
        btnUnits.setOnClickListener { view ->
            showPopupMenu(view)
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    // ==========================================
    // CONTEXT MENU (Long Press)
    // ==========================================
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.menu_context_formula, menu)
        menu?.setHeaderTitle("Options")
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.ctx_copy -> {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Formula", "Area = πr²")
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "Copied to Clipboard", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.ctx_share -> {
                Toast.makeText(this, "Sharing...", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    // ==========================================
    // POPUP MENU (Single Click)
    // ==========================================
    private fun showPopupMenu(view: View) {
        val popup = PopupMenu(this, view)
        popup.menuInflater.inflate(R.menu.menu_popup_units, popup.menu)

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.unit_meters -> {
                    Toast.makeText(this, "Units: Meters", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.unit_cm -> {
                    Toast.makeText(this, "Units: Centimeters", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.unit_feet -> {
                    Toast.makeText(this, "Units: Feet", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}