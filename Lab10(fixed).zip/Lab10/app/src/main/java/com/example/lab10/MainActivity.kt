package com.example.lab10

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.example.lab10.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        // Using a cleaner background or a more subtle gradient for better readability
        val gradient = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#F5F5F5"), Color.parseColor("#E0E0E0"))
        )
        binding.mainContentLayout.background = gradient

        val toggle = ActionBarDrawerToggle(
            this, binding.drawerLayout, binding.toolbar,
            android.R.string.ok, android.R.string.cancel
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Accessing buttons inside the NavigationView
        val btnSms: Button = binding.navView.findViewById(R.id.btnSms)
        btnSms.setOnClickListener {
            val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = "smsto:0123456789".toUri()
                putExtra("sms_body", "Hello, this is my Lab10 project!")
            }
            startActivity(smsIntent)
            binding.drawerLayout.closeDrawers()
        }

        val btnEmail: Button = binding.navView.findViewById(R.id.btnEmail)
        btnEmail.setOnClickListener {
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = "mailto:".toUri()
                putExtra(Intent.EXTRA_EMAIL, arrayOf("student@example.com"))
                putExtra(Intent.EXTRA_SUBJECT, "Lab 10 Submission")
                putExtra(Intent.EXTRA_TEXT, "Hello, here is my interactive app code.")
            }
            startActivity(Intent.createChooser(emailIntent, "Pick an Email Client"))
            binding.drawerLayout.closeDrawers()
        }
    }
}