package com.example.lab3 // CHANGE THIS to your package name

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ConverterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_converter)

        // 1. Link Views
        val spinner = findViewById<Spinner>(R.id.spinner_units)
        val etValue = findViewById<EditText>(R.id.et_value)
        val btnConvert = findViewById<Button>(R.id.btn_convert)
        val tvResult = findViewById<TextView>(R.id.tv_result_conv)

        // 2. Setup Spinner Options (The List)
        // We create a list of conversion types
        val conversionOptions = arrayOf(
            "Meters to Kilometers",
            "Kilometers to Meters",
            "Miles to Kilometers",
            "Kilometers to Miles",
            "Celsius to Fahrenheit"
        )

        // We use an 'Adapter' to put the list inside the Spinner
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, conversionOptions)
        spinner.adapter = adapter

        // 3. Button Logic
        btnConvert.setOnClickListener {
            val inputStr = etValue.text.toString()

            if (inputStr.isNotEmpty()) {
                val input = inputStr.toDouble()
                var result = 0.0

                // Check what the user selected in the dropdown
                val selectedOption = spinner.selectedItem.toString()

                // Perform the math based on selection
                when (selectedOption) {
                    "Meters to Kilometers" -> result = input / 1000
                    "Kilometers to Meters" -> result = input * 1000
                    "Miles to Kilometers" -> result = input * 1.60934
                    "Kilometers to Miles" -> result = input / 1.60934
                    "Celsius to Fahrenheit" -> result = (input * 9/5) + 32
                }

                // Show Result (formatted to 2 decimal places)
                tvResult.text = String.format("%.2f", result)

            } else {
                Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show()
            }
        }
    }
}