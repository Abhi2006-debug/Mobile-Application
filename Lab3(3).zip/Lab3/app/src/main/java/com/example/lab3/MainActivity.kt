package com.example.lab3 // IMPORTANT: Make sure this matches your actual package name

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Link the "Matrix Solver" Button
        val btnMatrix = findViewById<Button>(R.id.btn_matrix)
        btnMatrix.setOnClickListener {
            // Intent to open the Matrix Screen
            val intent = Intent(this, MatrixActivity::class.java)
            startActivity(intent)
        }

        // 2. Link the "Physics (Optics)" Button
        val btnPhysics = findViewById<Button>(R.id.btn_physics)
        btnPhysics.setOnClickListener {
            // Intent to open the Physics Screen
            val intent = Intent(this, PhysicsActivity::class.java)
            startActivity(intent)
        }

        // 3. Link the "Unit Converter" Button
        val btnConverter = findViewById<Button>(R.id.btn_converter)
        btnConverter.setOnClickListener {
            // Check if the Converter screen exists, otherwise show a "Coming Soon" message
            // (You can replace this Toast with the real intent once you create the screen)
            val intent = Intent(this, ConverterActivity::class.java)
            startActivity(intent)
        }
        val btnScientific = findViewById<Button>(R.id.btn_scientific)
        btnScientific.setOnClickListener {
            val intent = Intent(this, ScientificCalculatorActivity::class.java)
            startActivity(intent)
        }
    }
}