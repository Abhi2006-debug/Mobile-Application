package com.example.yourapp // Change this to your actual package name

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.yourapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // Using ViewBinding for better performance and to avoid 'findViewById'
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1. Setup the Toolbar and Background
        setupUI()

        // 2. Setup the Navigation Drawer Toggle
        val toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            android.R.string.ok,
            android.R.string.cancel
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // 3. Setup Custom Drawer Interactions
        // We find the buttons inside the NavigationView's custom layout
        val btnSms = binding.navView.findViewById<Button>(R.id.btnSms)
        val btnEmail = binding.navView.findViewById<Button>(R.id.btnEmail)

        btnSms.setOnClickListener {
            // ADVANCEMENT: Pre-filling data makes the app more "interactable"
            sendSms("1234567890", "Hello! This is an advanced SMS intent.")
            binding.drawerLayout.closeDrawers()
        }

        btnEmail.setOnClickListener {
            // ADVANCEMENT: Using mailto: ensures ONLY email apps respond
            sendEmail("test@example.com", "Project Query", "Body of the interactive email.")
            binding.drawerLayout.closeDrawers()
        }
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)

        // ADVANCEMENT: Setting a dynamic gradient background to the main content
        val gradient = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#6200EE"), // Purple 500
                Color.parseColor("#3700B3")  // Darker Purple
            )
        )
        binding.mainContentLayout.background = gradient
    }

    private fun sendSms(number: String, message: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$number")
            putExtra("sms_body", message)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No SMS app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendEmail(recipient: String, subject: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:") // Only email apps
            putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }

        try {
            // ADVANCEMENT: Using a Chooser so the user has a professional selection UI
            startActivity(Intent.createChooser(intent, "Send Email via..."))
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}