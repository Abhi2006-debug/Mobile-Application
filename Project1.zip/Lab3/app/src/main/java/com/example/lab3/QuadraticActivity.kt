package com.example.lab3

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.sqrt

class QuadraticActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quadratic)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarQuad)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val etA = findViewById<EditText>(R.id.et_a)
        val etB = findViewById<EditText>(R.id.et_b)
        val etC = findViewById<EditText>(R.id.et_c)
        val btnSolve = findViewById<Button>(R.id.btn_solve_quad)
        val tvResult = findViewById<TextView>(R.id.tv_result_quad)
        val tvLiveEq = findViewById<TextView>(R.id.tvLiveEq)
        val tvAnalysis = findViewById<TextView>(R.id.tvAnalysis)
        val cardAnalysis = findViewById<View>(R.id.cardAnalysis)

        // ── Live equation preview ──
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val aStr = etA.text.toString()
                val bStr = etB.text.toString()
                val cStr = etC.text.toString()
                if (aStr.isNotEmpty() || bStr.isNotEmpty() || cStr.isNotEmpty()) {
                    val aV = aStr.toDoubleOrNull() ?: 0.0
                    val bV = bStr.toDoubleOrNull() ?: 0.0
                    val cV = cStr.toDoubleOrNull() ?: 0.0
                    tvLiveEq.text = buildEquation(aV, bV, cV)
                } else {
                    tvLiveEq.text = "Enter coefficients below"
                }
            }
        }
        etA.addTextChangedListener(watcher)
        etB.addTextChangedListener(watcher)
        etC.addTextChangedListener(watcher)

        // ── Solve button ──
        btnSolve.setOnClickListener {
            val a = etA.text.toString().toDoubleOrNull()
            val b = etB.text.toString().toDoubleOrNull()
            val c = etC.text.toString().toDoubleOrNull()

            if (a != null && b != null && c != null) {

                // CASE 1: Linear (a = 0)
                if (a == 0.0) {
                    if (b != 0.0) {
                        val root = -c / b
                        tvResult.text = "This is a Linear Equation (a = 0)\n\nRoot:  x = ${fmt(root)}"
                        cardAnalysis.visibility = View.GONE
                        try { DatabaseHelper(this).insertLog("Quadratic", "Linear: ${b}x + $c = 0, root = $root") } catch (_: Exception) {}
                    } else {
                        tvResult.text = "Invalid Equation\na and b cannot both be 0"
                        cardAnalysis.visibility = View.GONE
                    }
                    return@setOnClickListener
                }

                // CASE 2: Quadratic
                val discriminant = (b * b) - (4 * a * c)
                val vertex_x = -b / (2 * a)
                val vertex_y = a * vertex_x * vertex_x + b * vertex_x + c

                // Build analysis
                cardAnalysis.visibility = View.VISIBLE
                val sb = StringBuilder()
                sb.appendLine("Discriminant (D)  = b²-4ac")
                sb.appendLine("                  = ${fmt(b*b)} - ${fmt(4*a*c)}")
                sb.appendLine("                  = ${fmt(discriminant)}")
                sb.appendLine()
                sb.appendLine("Vertex            = (${fmt(vertex_x)}, ${fmt(vertex_y)})")
                sb.appendLine("Axis of Symmetry  = x = ${fmt(vertex_x)}")
                sb.appendLine("Parabola opens    = ${if (a > 0) "Upward ↑" else "Downward ↓"}")
                sb.appendLine()
                when {
                    discriminant > 0 -> sb.appendLine("D > 0 → Two distinct real roots")
                    discriminant == 0.0 -> sb.appendLine("D = 0 → One repeated real root")
                    else -> sb.appendLine("D < 0 → Two complex conjugate roots")
                }
                tvAnalysis.text = sb.toString()

                // Build result
                if (discriminant > 0) {
                    val root1 = (-b + sqrt(discriminant)) / (2 * a)
                    val root2 = (-b - sqrt(discriminant)) / (2 * a)
                    tvResult.text = "Two Real Roots\n\nx₁ = ${fmt(root1)}\nx₂ = ${fmt(root2)}"
                    try { DatabaseHelper(this).insertLog("Quadratic", "${a}x²+${b}x+$c=0 → x₁=${fmt(root1)}, x₂=${fmt(root2)}") } catch (_: Exception) {}

                } else if (discriminant == 0.0) {
                    val root = -b / (2 * a)
                    tvResult.text = "One Repeated Root\n\nx = ${fmt(root)}"
                    try { DatabaseHelper(this).insertLog("Quadratic", "${a}x²+${b}x+$c=0 → x=${fmt(root)} (repeated)") } catch (_: Exception) {}

                } else {
                    val realPart = -b / (2 * a)
                    val imagPart = sqrt(abs(discriminant)) / (2 * a)
                    val rStr = if (abs(realPart) < 1e-10) "" else fmt(realPart)
                    val sign = if (rStr.isEmpty()) "±" else " ± "
                    tvResult.text = "Complex Roots\n\nx = ${rStr}${sign}${fmt(abs(imagPart))}i"
                    try { DatabaseHelper(this).insertLog("Quadratic", "${a}x²+${b}x+$c=0 → Complex roots") } catch (_: Exception) {}
                }

            } else {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── Helpers ──
    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble() && abs(v) < 1e15)
            v.toLong().toString()
        else String.format("%.4f", v)
    }

    private fun buildEquation(a: Double, b: Double, c: Double): String {
        val sb = StringBuilder()
        // a term
        when {
            a == 1.0 -> sb.append("x²")
            a == -1.0 -> sb.append("-x²")
            a != 0.0 -> sb.append("${fmt(a)}x²")
        }
        // b term
        when {
            b > 0 && sb.isNotEmpty() -> sb.append(" + ${if (b == 1.0) "" else fmt(b)}x")
            b == 1.0 && sb.isEmpty() -> sb.append("x")
            b < 0 -> sb.append(" − ${if (b == -1.0) "" else fmt(abs(b))}x")
            b != 0.0 && sb.isEmpty() -> sb.append("${fmt(b)}x")
        }
        // c term
        when {
            c > 0 && sb.isNotEmpty() -> sb.append(" + ${fmt(c)}")
            c < 0 -> sb.append(" − ${fmt(abs(c))}")
            c != 0.0 && sb.isEmpty() -> sb.append(fmt(c))
        }
        if (sb.isEmpty()) sb.append("0")
        sb.append(" = 0")
        return sb.toString()
    }
}