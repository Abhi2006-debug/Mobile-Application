package com.example.lab3

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Formula(val name: String, val equation: String, val category: String, val description: String = "")

class FormulaAdapter(
    private var formulaList: List<Formula>,
    private val onItemClick: (Formula) -> Unit
) : RecyclerView.Adapter<FormulaAdapter.FormulaViewHolder>() {

    class FormulaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_formula_name)
        val tvEquation: TextView = itemView.findViewById(R.id.tv_formula_equation)
        val tvCategory: TextView = itemView.findViewById(R.id.tv_formula_category)
        val tvDesc: TextView = itemView.findViewById(R.id.tv_formula_desc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FormulaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_formula, parent, false)
        return FormulaViewHolder(view)
    }

    override fun onBindViewHolder(holder: FormulaViewHolder, position: Int) {
        val f = formulaList[position]
        holder.tvName.text = f.name
        holder.tvEquation.text = f.equation
        holder.tvCategory.text = f.category
        holder.tvDesc.text = f.description
        holder.itemView.setOnClickListener { onItemClick(f) }
    }

    override fun getItemCount(): Int = formulaList.size

    fun updateData(newList: List<Formula>) {
        this.formulaList = newList
        notifyDataSetChanged()
    }
}