package com.example.lab3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    private val TAG = "Logdeb"

    // NEW: Variable to hold the DrawerLayout
    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ==========================================
        // NEW: SETUP TOOLBAR & NAVIGATION DRAWER
        // ==========================================
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar) // This replaces the default action bar with our custom one

        drawerLayout = findViewById(R.id.drawer_layout)
        val navView = findViewById<NavigationView>(R.id.nav_view)

        // Adds the Hamburger Icon and Syncs it with the Drawer
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.open_drawer, R.string.close_drawer // Note: Add these to res/values/strings.xml
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Handle clicks inside the drawer (History, SMS & Email)
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                // NEW: Launch the History screen!
                R.id.nav_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                }
                R.id.nav_sms -> sendSMS()
                R.id.nav_email -> sendEmail()
            }
            // Close drawer after making a selection
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // ==========================================
        // CARD DASHBOARD CLICK LISTENERS
        // ==========================================

        findViewById<android.view.View>(R.id.btn_matrix).setOnClickListener {
            startActivity(Intent(this, MatrixActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_physics).setOnClickListener {
            startActivity(Intent(this, PhysicsActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_converter).setOnClickListener {
            startActivity(Intent(this, ConverterActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_scientific).setOnClickListener {
            startActivity(Intent(this, ScientificCalculatorActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_quadratic).setOnClickListener {
            startActivity(Intent(this, QuadraticActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_vector).setOnClickListener {
            startActivity(Intent(this, VectorActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_formulas).setOnClickListener {
            startActivity(Intent(this, FormulaDashboardActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btn_graph).setOnClickListener {
            startActivity(Intent(this, graph_plotter::class.java))
        }
        findViewById<android.view.View>(R.id.btn_geometry).setOnClickListener {
            startActivity(Intent(this, GeometrySolver::class.java))
        }

        // Modern way to handle the Back Button
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(androidx.core.view.GravityCompat.START)) {
                    // If the drawer is open, close it
                    drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
                } else {
                    // If the drawer is already closed, behave like a normal back button
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }


    // ==========================================
    // NEW: SMS AND EMAIL INTENT FUNCTIONS
    // ==========================================

    // Inside MainActivity.kt

    private fun sendSMS() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:1234567890")
            putExtra("sms_body", "Hello MathENV Support, I have a question: ")
        }
        if (intent.resolveActivity(packageManager) != null) {

            // NEW: Save to Database!
            val db = DatabaseHelper(this)
            db.insertLog("Communication", "Opened SMS Support")

            startActivity(intent)
        } else {
            Toast.makeText(this, "No SMS app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendEmail() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf("support@mathenv.com"))
            putExtra(Intent.EXTRA_SUBJECT, "MathENV App Inquiry")
        }
        if (intent.resolveActivity(packageManager) != null) {

            // NEW: Save to Database!
            val db = DatabaseHelper(this)
            db.insertLog("Communication", "Opened Email Support")

            startActivity(intent)
        } else {
            Toast.makeText(this, "No Email app found", Toast.LENGTH_SHORT).show()
        }
    }



    // ==========================================
    // YOUR EXISTING LIFECYCLE LOGGING (UNTOUCHED)
    // ==========================================

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart: Activity is becoming visible")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: Activity is now interactive (User can touch it)")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause: Activity is partially obscured or user is leaving")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop: Activity is no longer visible (Backgrounded)")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "onRestart: Activity is coming back from background")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy: Activity is being destroyed (Memory cleared)")
    }
}