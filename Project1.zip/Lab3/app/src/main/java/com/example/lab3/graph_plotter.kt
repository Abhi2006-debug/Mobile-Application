package com.example.lab3

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class graph_plotter : AppCompatActivity() {

    private var currentGraphView: GraphCanvasView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph_plotter)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarGraph)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val etFunction = findViewById<EditText>(R.id.et_function)
        val etXMin = findViewById<EditText>(R.id.et_x_min)
        val etXMax = findViewById<EditText>(R.id.et_x_max)
        val graphContainer = findViewById<FrameLayout>(R.id.graph_container)
        val tvPlaceholder = findViewById<TextView>(R.id.tv_graph_placeholder)
        val tvFuncLabel = findViewById<TextView>(R.id.tv_func_label)
        val zoomControls = findViewById<LinearLayout>(R.id.zoom_controls)
        val btnZoomIn = findViewById<TextView>(R.id.btn_zoom_in)
        val btnZoomOut = findViewById<TextView>(R.id.btn_zoom_out)

        // ── Preset chips ──
        val presets = mapOf(
            R.id.chip_sinx to "sin(x)",
            R.id.chip_cosx to "cos(x)",
            R.id.chip_tanx to "tan(x)",
            R.id.chip_x2 to "x^2",
            R.id.chip_x3 to "x^3",
            R.id.chip_sqrtx to "sqrt(x)",
            R.id.chip_logx to "log(x)",
            R.id.chip_abs to "abs(x)"
        )
        for ((id, expr) in presets) {
            findViewById<Button>(id).setOnClickListener {
                etFunction.setText(expr)
            }
        }

        // ── Plot button ──
        findViewById<Button>(R.id.btn_plot).setOnClickListener {
            val functionText = etFunction.text.toString().trim().lowercase()
            if (functionText.isEmpty()) {
                Toast.makeText(this, "Enter a function", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val minX = etXMin.text.toString().toFloatOrNull() ?: -10f
            val maxX = etXMax.text.toString().toFloatOrNull() ?: 10f
            if (minX >= maxX) {
                Toast.makeText(this, "X min must be less than X max", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Log to DB
            try {
                val db = DatabaseHelper(this)
                db.insertLog("Graph Plotter", "Plotted f(x)=$functionText from $minX to $maxX")
            } catch (_: Exception) {}

            tvPlaceholder.visibility = View.GONE
            zoomControls.visibility = View.VISIBLE
            tvFuncLabel.visibility = View.VISIBLE
            tvFuncLabel.text = "f(x) = $functionText"

            currentGraphView?.let { graphContainer.removeView(it) }
            currentGraphView = GraphCanvasView(this, minX, maxX, functionText)
            graphContainer.addView(currentGraphView, 0)
        }

        btnZoomIn.setOnClickListener { currentGraphView?.zoomIn() }
        btnZoomOut.setOnClickListener { currentGraphView?.zoomOut() }
    }

    // ═══════════════════════════════════════════════
    //  EXPRESSION PARSER — supports: +, -, *, /, ^,
    //  sin, cos, tan, log, ln, sqrt, abs, pi, e
    // ═══════════════════════════════════════════════
    companion object {
        fun evaluate(expr: String, x: Double): Double {
            val tokens = tokenize(expr.replace(" ", "").lowercase(), x)
            val pos = intArrayOf(0)
            val result = parseExpr(tokens, pos)
            return result
        }

        private fun tokenize(expr: String, x: Double): List<Any> {
            val tokens = mutableListOf<Any>()
            var i = 0
            while (i < expr.length) {
                val ch = expr[i]
                when {
                    ch in "+-*/^()" -> { tokens.add(ch); i++ }
                    ch == 'x' -> { tokens.add(x); i++ }
                    ch.isDigit() || ch == '.' -> {
                        var num = ""
                        while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                            num += expr[i]; i++
                        }
                        tokens.add(num.toDouble())
                    }
                    ch.isLetter() -> {
                        var name = ""
                        while (i < expr.length && expr[i].isLetter()) {
                            name += expr[i]; i++
                        }
                        when (name) {
                            "pi" -> tokens.add(PI)
                            "e" -> tokens.add(E)
                            else -> tokens.add(name) // function name
                        }
                    }
                    else -> i++
                }
            }
            // Insert implicit multiplication: 2x, 2sin, )(, x(, etc.
            val result = mutableListOf<Any>()
            for (j in tokens.indices) {
                if (j > 0) {
                    val prev = tokens[j - 1]
                    val curr = tokens[j]
                    val needMul = (prev is Double && (curr is Double || curr is String || curr == '(')) ||
                            (prev == ')' && (curr is Double || curr is String || curr == '('))
                    if (needMul) result.add('*')
                }
                result.add(tokens[j])
            }
            return result
        }

        private fun parseExpr(tokens: List<Any>, pos: IntArray): Double {
            var result = parseTerm(tokens, pos)
            while (pos[0] < tokens.size) {
                val op = tokens[pos[0]]
                if (op == '+' || op == '-') {
                    pos[0]++
                    val right = parseTerm(tokens, pos)
                    result = if (op == '+') result + right else result - right
                } else break
            }
            return result
        }

        private fun parseTerm(tokens: List<Any>, pos: IntArray): Double {
            var result = parsePower(tokens, pos)
            while (pos[0] < tokens.size) {
                val op = tokens[pos[0]]
                if (op == '*' || op == '/') {
                    pos[0]++
                    val right = parsePower(tokens, pos)
                    result = if (op == '*') result * right else result / right
                } else break
            }
            return result
        }

        private fun parsePower(tokens: List<Any>, pos: IntArray): Double {
            var base = parseUnary(tokens, pos)
            if (pos[0] < tokens.size && tokens[pos[0]] == '^') {
                pos[0]++
                val exp = parsePower(tokens, pos) // right-associative
                base = base.pow(exp)
            }
            return base
        }

        private fun parseUnary(tokens: List<Any>, pos: IntArray): Double {
            if (pos[0] < tokens.size && tokens[pos[0]] == '-') {
                pos[0]++; return -parseAtom(tokens, pos)
            }
            if (pos[0] < tokens.size && tokens[pos[0]] == '+') {
                pos[0]++
            }
            return parseAtom(tokens, pos)
        }

        private fun parseAtom(tokens: List<Any>, pos: IntArray): Double {
            if (pos[0] >= tokens.size) return 0.0
            val token = tokens[pos[0]]
            return when {
                token is Double -> { pos[0]++; token }
                token == '(' -> {
                    pos[0]++ // skip (
                    val v = parseExpr(tokens, pos)
                    if (pos[0] < tokens.size && tokens[pos[0]] == ')') pos[0]++
                    v
                }
                token is String -> {
                    pos[0]++ // skip function name
                    if (pos[0] < tokens.size && tokens[pos[0]] == '(') pos[0]++
                    val arg = parseExpr(tokens, pos)
                    if (pos[0] < tokens.size && tokens[pos[0]] == ')') pos[0]++
                    applyFunc(token, arg)
                }
                else -> { pos[0]++; 0.0 }
            }
        }

        private fun applyFunc(name: String, arg: Double): Double = when (name) {
            "sin" -> sin(arg)
            "cos" -> cos(arg)
            "tan" -> tan(arg)
            "asin" -> asin(arg)
            "acos" -> acos(arg)
            "atan" -> atan(arg)
            "log" -> log10(arg)
            "ln" -> ln(arg)
            "sqrt" -> sqrt(arg)
            "abs" -> abs(arg)
            "exp" -> exp(arg)
            "ceil" -> ceil(arg)
            "floor" -> floor(arg)
            else -> Double.NaN
        }
    }

    // ═══════════════════════════════════════════════
    //  PREMIUM GRAPH CANVAS with grid + tick labels
    // ═══════════════════════════════════════════════
    @SuppressLint("ViewConstructor")
    private inner class GraphCanvasView(
        context: Context,
        private val origMinX: Float,
        private val origMaxX: Float,
        private val function: String
    ) : View(context) {

        private var scaleFactor = 1.0f

        private val scaleDetector = ScaleGestureDetector(context,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(0.1f, 30f)
                    invalidate()
                    return true
                }
            })

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            scaleDetector.onTouchEvent(event)
            return true
        }

        fun zoomIn() { scaleFactor = (scaleFactor * 1.5f).coerceAtMost(30f); invalidate() }
        fun zoomOut() { scaleFactor = (scaleFactor / 1.5f).coerceAtLeast(0.1f); invalidate() }

        // Paints
        private val gridPaint = Paint().apply {
            color = Color.parseColor("#1A3A5C"); strokeWidth = 1f
        }
        private val axisPaint = Paint().apply {
            color = Color.parseColor("#3D5AFE"); strokeWidth = 2.5f; isAntiAlias = true
        }
        private val curvePaint = Paint().apply {
            color = Color.parseColor("#00E5FF"); strokeWidth = 3f
            style = Paint.Style.STROKE; isAntiAlias = true
        }
        private val labelPaint = Paint().apply {
            color = Color.parseColor("#5C6BC0"); textSize = 28f; isAntiAlias = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w == 0f || h == 0f) return

            // Compute visible range
            val cx = (origMinX + origMaxX) / 2f
            val spanX = (origMaxX - origMinX) / scaleFactor
            val minX = cx - spanX / 2f
            val maxX = cx + spanX / 2f

            // Auto Y range from sampling
            var yLo = Float.MAX_VALUE; var yHi = Float.MIN_VALUE
            val samples = 300
            for (i in 0..samples) {
                val x = minX + (maxX - minX) * (i.toFloat() / samples)
                val y = evaluate(function, x.toDouble()).toFloat()
                if (y.isFinite()) { if (y < yLo) yLo = y; if (y > yHi) yHi = y }
            }
            val yPad = (yHi - yLo).coerceAtLeast(1f) * 0.15f
            val minY = yLo - yPad; val maxY = yHi + yPad

            fun sx(x: Float) = w * (x - minX) / (maxX - minX)
            fun sy(y: Float) = h - h * (y - minY) / (maxY - minY)

            // ── Grid lines ──
            val gridStep = niceStep((maxX - minX) / 6.0)
            var gx = (floor(minX / gridStep.toFloat()) * gridStep).toFloat()
            while (gx <= maxX) {
                val px = sx(gx)
                canvas.drawLine(px, 0f, px, h, gridPaint)
                gx += gridStep.toFloat()
            }
            var gy = (floor(minY / gridStep.toFloat()) * gridStep).toFloat()
            while (gy <= maxY) {
                val py = sy(gy)
                canvas.drawLine(0f, py, w, py, gridPaint)
                gy += gridStep.toFloat()
            }

            // ── Axes ──
            val ox = sx(0f).coerceIn(0f, w); val oy = sy(0f).coerceIn(0f, h)
            canvas.drawLine(ox, 0f, ox, h, axisPaint)
            canvas.drawLine(0f, oy, w, oy, axisPaint)

            // ── Tick labels ──
            gx = (floor(minX / gridStep.toFloat()) * gridStep).toFloat()
            while (gx <= maxX) {
                val px = sx(gx)
                if (abs(gx) > gridStep.toFloat() * 0.1f) {
                    canvas.drawText(fmtTick(gx), px + 4, oy - 6, labelPaint)
                }
                gx += gridStep.toFloat()
            }
            gy = (floor(minY / gridStep.toFloat()) * gridStep).toFloat()
            while (gy <= maxY) {
                val py = sy(gy)
                if (abs(gy) > gridStep.toFloat() * 0.1f) {
                    canvas.drawText(fmtTick(gy), ox + 6, py - 4, labelPaint)
                }
                gy += gridStep.toFloat()
            }

            // ── Curve ──
            val path = Path()
            var started = false
            val pts = 500
            for (i in 0..pts) {
                val x = minX + (maxX - minX) * (i.toFloat() / pts)
                val y = evaluate(function, x.toDouble()).toFloat()
                val px = sx(x); val py = sy(y)
                if (y.isFinite() && py in -h..2 * h) {
                    if (!started) { path.moveTo(px, py); started = true }
                    else path.lineTo(px, py)
                } else {
                    started = false
                }
            }
            canvas.drawPath(path, curvePaint)
        }

        private fun niceStep(rough: Double): Double {
            val exp = floor(log10(abs(rough))).toInt()
            val frac = rough / 10.0.pow(exp)
            val nice = when {
                frac <= 1.5 -> 1.0
                frac <= 3.0 -> 2.0
                frac <= 7.0 -> 5.0
                else -> 10.0
            }
            return nice * 10.0.pow(exp)
        }

        private fun fmtTick(v: Float): String {
            return if (v == v.toLong().toFloat()) v.toLong().toString()
            else String.format("%.1f", v)
        }
    }
}