package com.example.lab3

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MatrixActivity : AppCompatActivity() {

    // Matrix A cells
    private val aIds = arrayOf(
        intArrayOf(R.id.a11, R.id.a12, R.id.a13),
        intArrayOf(R.id.a21, R.id.a22, R.id.a23),
        intArrayOf(R.id.a31, R.id.a32, R.id.a33)
    )
    // Matrix B cells
    private val bIds = arrayOf(
        intArrayOf(R.id.b11, R.id.b12, R.id.b13),
        intArrayOf(R.id.b21, R.id.b22, R.id.b23),
        intArrayOf(R.id.b31, R.id.b32, R.id.b33)
    )

    private var size = 2
    private lateinit var tvResult: TextView
    private lateinit var btnShare: Button
    private var lastResult = ""

    // Two-matrix operations
    private val twoMatrixOps = setOf("Multiply (A×B)", "Add (A+B)", "Subtract (A−B)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_matrix)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarMatrix)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        tvResult = findViewById(R.id.tv_result)
        btnShare = findViewById(R.id.btn_share)

        // Operation spinner
        val ops = arrayOf("Determinant", "Transpose", "Inverse", "Adjoint",
            "Trace", "Multiply (A×B)", "Add (A+B)", "Subtract (A−B)")
        val spinner = findViewById<Spinner>(R.id.spinnerOp)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ops)

        val cardB = findViewById<View>(R.id.cardMatrixB)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                cardB.visibility = if (ops[pos] in twoMatrixOps) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Size toggle
        val btn2 = findViewById<Button>(R.id.btn2x2)
        val btn3 = findViewById<Button>(R.id.btn3x3)
        btn2.setOnClickListener { setSize(2, btn2, btn3) }
        btn3.setOnClickListener { setSize(3, btn2, btn3) }

        // Calculate
        findViewById<Button>(R.id.btnCalcMatrix).setOnClickListener {
            calculate(ops[spinner.selectedItemPosition])
        }

        // Clear
        findViewById<Button>(R.id.btnClearMatrix).setOnClickListener {
            clearAll()
        }

        // Share
        btnShare.setOnClickListener {
            val intent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, "Solved with MathEnv!\n$lastResult")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(intent, "Share via"))
        }
    }

    // ══════════════════════════════════════
    //  SIZE TOGGLE
    // ══════════════════════════════════════
    private fun setSize(n: Int, btn2: Button, btn3: Button) {
        size = n
        btn2.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (n == 2) 0xFF1565C0.toInt() else 0xFF2A2D37.toInt())
        btn2.setTextColor(if (n == 2) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())
        btn3.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (n == 3) 0xFF1565C0.toInt() else 0xFF2A2D37.toInt())
        btn3.setTextColor(if (n == 3) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())

        // Show/hide 3rd column cells and 3rd row
        val show3 = n == 3
        for (row in 0..1) {
            findViewById<EditText>(aIds[row][2]).visibility = if (show3) View.VISIBLE else View.GONE
            findViewById<EditText>(bIds[row][2]).visibility = if (show3) View.VISIBLE else View.GONE
        }
        findViewById<LinearLayout>(R.id.rowA3).visibility = if (show3) View.VISIBLE else View.GONE
        findViewById<LinearLayout>(R.id.rowB3).visibility = if (show3) View.VISIBLE else View.GONE
    }

    // ══════════════════════════════════════
    //  CALCULATE
    // ══════════════════════════════════════
    private fun calculate(op: String) {
        val a = readMatrix(aIds) ?: return
        val b = if (op in twoMatrixOps) readMatrix(bIds) ?: return else null

        lastResult = when (op) {
            "Determinant" -> {
                val det = if (size == 2) det2(a) else det3(a)
                "Determinant = ${fmt(det)}"
            }
            "Transpose" -> "Transpose of A:\n${matToStr(transpose(a))}"
            "Inverse" -> {
                val det = if (size == 2) det2(a) else det3(a)
                if (det == 0.0) { "Inverse does not exist (det = 0)" }
                else {
                    val inv = inverse(a, det)
                    "det(A) = ${fmt(det)}\n\nA⁻¹ =\n${matToStr(inv)}"
                }
            }
            "Adjoint" -> {
                val adj = adjoint(a)
                "Adjoint of A:\n${matToStr(adj)}"
            }
            "Trace" -> {
                var trace = 0.0
                for (i in 0 until size) trace += a[i][i]
                "Trace = ${fmt(trace)}"
            }
            "Multiply (A×B)" -> {
                val c = multiply(a, b!!)
                "A × B =\n${matToStr(c)}"
            }
            "Add (A+B)" -> {
                val c = Array(size) { i -> DoubleArray(size) { j -> a[i][j] + b!![i][j] } }
                "A + B =\n${matToStr(c)}"
            }
            "Subtract (A−B)" -> {
                val c = Array(size) { i -> DoubleArray(size) { j -> a[i][j] - b!![i][j] } }
                "A − B =\n${matToStr(c)}"
            }
            else -> "—"
        }

        tvResult.text = lastResult
        btnShare.visibility = View.VISIBLE
        try { DatabaseHelper(this).insertLog("Matrix", "$op (${size}×${size}): ${lastResult.lines().first()}") } catch (_: Exception) {}
    }

    // ══════════════════════════════════════
    //  MATRIX MATH
    // ══════════════════════════════════════
    private fun det2(m: Array<DoubleArray>): Double = m[0][0]*m[1][1] - m[0][1]*m[1][0]

    private fun det3(m: Array<DoubleArray>): Double {
        return m[0][0]*(m[1][1]*m[2][2] - m[1][2]*m[2][1]) -
               m[0][1]*(m[1][0]*m[2][2] - m[1][2]*m[2][0]) +
               m[0][2]*(m[1][0]*m[2][1] - m[1][1]*m[2][0])
    }

    private fun transpose(m: Array<DoubleArray>): Array<DoubleArray> {
        return Array(size) { i -> DoubleArray(size) { j -> m[j][i] } }
    }

    private fun adjoint(m: Array<DoubleArray>): Array<DoubleArray> {
        if (size == 2) {
            return arrayOf(
                doubleArrayOf(m[1][1], -m[0][1]),
                doubleArrayOf(-m[1][0], m[0][0])
            )
        }
        // 3×3 cofactor matrix transposed
        val cof = Array(3) { DoubleArray(3) }
        for (i in 0..2) for (j in 0..2) {
            val minor = minor(m, i, j)
            cof[i][j] = (if ((i+j) % 2 == 0) 1 else -1) * det2(minor)
        }
        return transpose(cof)
    }

    private fun inverse(m: Array<DoubleArray>, det: Double): Array<DoubleArray> {
        val adj = adjoint(m)
        return Array(size) { i -> DoubleArray(size) { j -> adj[i][j] / det } }
    }

    private fun minor(m: Array<DoubleArray>, row: Int, col: Int): Array<DoubleArray> {
        val result = Array(2) { DoubleArray(2) }
        var ri = 0
        for (i in 0..2) {
            if (i == row) continue
            var ci = 0
            for (j in 0..2) {
                if (j == col) continue
                result[ri][ci] = m[i][j]
                ci++
            }
            ri++
        }
        return result
    }

    private fun multiply(a: Array<DoubleArray>, b: Array<DoubleArray>): Array<DoubleArray> {
        return Array(size) { i ->
            DoubleArray(size) { j ->
                var sum = 0.0
                for (k in 0 until size) sum += a[i][k] * b[k][j]
                sum
            }
        }
    }

    // ══════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════
    private fun readMatrix(ids: Array<IntArray>): Array<DoubleArray>? {
        val m = Array(size) { DoubleArray(size) }
        for (i in 0 until size) for (j in 0 until size) {
            val et = findViewById<EditText>(ids[i][j])
            val v = et.text.toString().toDoubleOrNull()
            if (v == null) {
                Toast.makeText(this, "Fill all matrix cells", Toast.LENGTH_SHORT).show()
                return null
            }
            m[i][j] = v
        }
        return m
    }

    private fun clearAll() {
        for (ids in arrayOf(aIds, bIds))
            for (row in ids) for (id in row)
                findViewById<EditText>(id).text.clear()
        tvResult.text = "Select an operation and enter matrix values"
        btnShare.visibility = View.GONE
    }

    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble() && kotlin.math.abs(v) < 1e15)
            v.toLong().toString()
        else String.format("%.4f", v)
    }

    private fun matToStr(m: Array<DoubleArray>): String {
        return m.joinToString("\n") { row ->
            "│ " + row.joinToString("  ") { fmt(it).padStart(8) } + " │"
        }
    }
}