package com.example.lab3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.asin
import kotlin.math.sin

class PhysicsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_physics)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarPhysics)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val etN1 = findViewById<EditText>(R.id.et_n1)
        val etTheta1 = findViewById<EditText>(R.id.et_theta1)
        val etN2 = findViewById<EditText>(R.id.et_n2)
        val btnCalc = findViewById<Button>(R.id.btn_calc_physics)
        val tvResult = findViewById<TextView>(R.id.tv_result_physics)
        val btnSearch = findViewById<Button>(R.id.btn_search_theory)

        // ── Preset media buttons (Medium 1) ──
        findViewById<Button>(R.id.btnAir1).setOnClickListener { etN1.setText("1.0") }
        findViewById<Button>(R.id.btnWater1).setOnClickListener { etN1.setText("1.33") }
        findViewById<Button>(R.id.btnGlass1).setOnClickListener { etN1.setText("1.5") }

        // ── Preset media buttons (Medium 2) ──
        findViewById<Button>(R.id.btnAir2).setOnClickListener { etN2.setText("1.0") }
        findViewById<Button>(R.id.btnWater2).setOnClickListener { etN2.setText("1.33") }
        findViewById<Button>(R.id.btnDiamond2).setOnClickListener { etN2.setText("2.42") }

        // ── Calculate ──
        btnCalc.setOnClickListener {
            val n1Str = etN1.text.toString()
            val theta1Str = etTheta1.text.toString()
            val n2Str = etN2.text.toString()

            if (n1Str.isEmpty() || theta1Str.isEmpty() || n2Str.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val n1 = n1Str.toDouble()
            val theta1Deg = theta1Str.toDouble()
            val n2 = n2Str.toDouble()

            val theta1Rad = Math.toRadians(theta1Deg)
            val sinTheta2 = (n1 * sin(theta1Rad)) / n2

            val sb = StringBuilder()
            sb.appendLine("Step-by-step Solution")
            sb.appendLine("━━━━━━━━━━━━━━━━━━━━")
            sb.appendLine()
            sb.appendLine("Given:")
            sb.appendLine("  n₁ = $n1  (${getMediaName(n1)})")
            sb.appendLine("  θ₁ = ${theta1Deg}°")
            sb.appendLine("  n₂ = $n2  (${getMediaName(n2)})")
            sb.appendLine()
            sb.appendLine("Applying Snell's Law:")
            sb.appendLine("  n₁ × sin(θ₁) = n₂ × sin(θ₂)")
            sb.appendLine("  sin(θ₂) = n₁ × sin(θ₁) / n₂")
            sb.appendLine("  sin(θ₂) = $n1 × sin(${theta1Deg}°) / $n2")
            sb.appendLine("  sin(θ₂) = ${String.format("%.6f", sinTheta2)}")
            sb.appendLine()

            if (sinTheta2 >= -1.0 && sinTheta2 <= 1.0) {
                val theta2Rad = asin(sinTheta2)
                val theta2Deg = Math.toDegrees(theta2Rad)

                sb.appendLine("Result:")
                sb.appendLine("  θ₂ = ${String.format("%.2f", theta2Deg)}°")
                sb.appendLine()

                // Classification
                when {
                    theta2Deg > theta1Deg -> sb.appendLine("⟶ Light bends AWAY from normal")
                    theta2Deg < theta1Deg -> sb.appendLine("⟶ Light bends TOWARD normal")
                    else -> sb.appendLine("⟶ No refraction (same angle)")
                }

                if (n1 > n2) {
                    val criticalAngle = Math.toDegrees(asin(n2 / n1))
                    sb.appendLine()
                    sb.appendLine("Critical Angle = ${String.format("%.2f", criticalAngle)}°")
                    sb.appendLine("(Total internal reflection if θ₁ > ${String.format("%.2f", criticalAngle)}°)")
                }

                tvResult.text = sb.toString()
                try { DatabaseHelper(this).insertLog("Physics", "Snell's Law: n1=$n1, θ1=${theta1Deg}°, n2=$n2 → θ2=${String.format("%.2f", theta2Deg)}°") } catch (_: Exception) {}
            } else {
                sb.appendLine("⚠️ Total Internal Reflection!")
                sb.appendLine()
                sb.appendLine("sin(θ₂) = ${String.format("%.4f", sinTheta2)}")
                sb.appendLine("Since |sin(θ₂)| > 1, no refraction occurs.")
                sb.appendLine("All light is reflected back into Medium 1.")

                val criticalAngle = Math.toDegrees(asin(n2 / n1))
                sb.appendLine()
                sb.appendLine("Critical Angle = ${String.format("%.2f", criticalAngle)}°")
                sb.appendLine("Your angle (${theta1Deg}°) exceeds this.")

                tvResult.text = sb.toString()
                try { DatabaseHelper(this).insertLog("Physics", "Snell's Law: n1=$n1, θ1=${theta1Deg}°, n2=$n2 → Total Internal Reflection") } catch (_: Exception) {}
            }
        }

        // ── Google search ──
        btnSearch.setOnClickListener {
            val uri = Uri.parse("https://www.google.com/search?q=Snell's+Law+Formula+Physics")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun getMediaName(n: Double): String {
        return when {
            n == 1.0 -> "Air/Vacuum"
            n == 1.33 -> "Water"
            n == 1.5 -> "Glass"
            n == 1.52 -> "Crown Glass"
            n == 2.42 -> "Diamond"
            n < 1.1 -> "Near vacuum"
            n < 1.4 -> "Light liquid"
            n < 1.6 -> "Glass-like"
            n < 2.0 -> "Dense material"
            else -> "Very dense material"
        }
    }
}