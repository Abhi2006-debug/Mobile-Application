package com.example.lab3

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class ScientificCalculatorActivity : AppCompatActivity() {

    private lateinit var tvScreen: TextView
    private lateinit var tvExpression: TextView
    private var firstValue = 0.0
    private var currentOperation = ""
    private var isNewOp = true
    private var isDegMode = true
    private val historyItems = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scientific_calculator)

        tvScreen = findViewById(R.id.tv_screen)
        tvExpression = findViewById(R.id.tv_expression)

        setupNumberButtons()
        setupOperationButtons()
        setupScientificButtons()
        setupExtraButtons()
        setupHistory()
    }

    // ══════════════════════════════════════
    //  NUMBER BUTTONS
    // ══════════════════════════════════════
    private fun setupNumberButtons() {
        val numberIds = listOf(
            R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4,
            R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9, R.id.btn_dot
        )

        val listener = View.OnClickListener { view ->
            val button = view as Button
            if (isNewOp || tvScreen.text == "Error") {
                tvScreen.text = ""
                isNewOp = false
            }
            if (button.text == "." && tvScreen.text.contains(".")) return@OnClickListener
            tvScreen.append(button.text)
        }

        for (id in numberIds) {
            findViewById<Button>(id).setOnClickListener(listener)
        }
    }

    // ══════════════════════════════════════
    //  BASIC OPERATIONS
    // ══════════════════════════════════════
    private fun setupOperationButtons() {
        val ops = mapOf(
            R.id.btn_add to "+",
            R.id.btn_sub to "−",
            R.id.btn_mul to "×",
            R.id.btn_div to "÷",
            R.id.btn_power to "^"
        )

        for ((id, op) in ops) {
            findViewById<Button>(id).setOnClickListener {
                if (tvScreen.text == "Error") return@setOnClickListener
                currentOperation = op
                firstValue = tvScreen.text.toString().toDoubleOrNull() ?: 0.0
                tvExpression.text = "${formatResult(firstValue)} $op"
                isNewOp = true
            }
        }

        // EQUALS
        findViewById<Button>(R.id.btn_equal).setOnClickListener {
            val secondText = tvScreen.text.toString()
            if (secondText == "Error" || secondText.isEmpty()) return@setOnClickListener
            val secondValue = secondText.toDoubleOrNull() ?: return@setOnClickListener

            var result = 0.0
            var error = false

            when (currentOperation) {
                "+" -> result = firstValue + secondValue
                "−" -> result = firstValue - secondValue
                "×" -> result = firstValue * secondValue
                "÷" -> { if (secondValue == 0.0) error = true else result = firstValue / secondValue }
                "^" -> result = firstValue.pow(secondValue)
            }

            val expr = "${formatResult(firstValue)} $currentOperation ${formatResult(secondValue)}"
            if (error) {
                tvScreen.text = "Error"
                tvExpression.text = "$expr = Error"
            } else {
                val r = formatResult(result)
                tvScreen.text = r
                tvExpression.text = "$expr = $r"
                addHistory("$expr = $r")
            }
            isNewOp = true
        }

        // AC
        findViewById<Button>(R.id.btn_clear).setOnClickListener {
            tvScreen.text = "0"
            tvExpression.text = ""
            firstValue = 0.0
            currentOperation = ""
            isNewOp = true
        }
    }

    // ══════════════════════════════════════
    //  SCIENTIFIC FUNCTIONS
    // ══════════════════════════════════════
    private fun setupScientificButtons() {
        // SIN
        findViewById<Button>(R.id.btn_sin).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            val angle = if (isDegMode) Math.toRadians(value) else value
            val result = sin(angle)
            val r = formatResult(result)
            tvScreen.text = r
            tvExpression.text = "sin(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r"
            addHistory("sin(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r")
            isNewOp = true
        }

        // COS
        findViewById<Button>(R.id.btn_cos).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            val r: String
            if (isDegMode && value % 180.0 == 90.0) {
                r = "0"; tvScreen.text = r
            } else {
                val angle = if (isDegMode) Math.toRadians(value) else value
                r = formatResult(cos(angle)); tvScreen.text = r
            }
            tvExpression.text = "cos(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r"
            addHistory("cos(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r")
            isNewOp = true
        }

        // TAN
        findViewById<Button>(R.id.btn_tan).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (isDegMode && (value - 90) % 180 == 0.0) {
                tvScreen.text = "Error"
                tvExpression.text = "tan(${formatResult(value)}°) = Undefined"
                addHistory("tan(${formatResult(value)}°) = Undefined")
            } else {
                val angle = if (isDegMode) Math.toRadians(value) else value
                val r = formatResult(tan(angle)); tvScreen.text = r
                tvExpression.text = "tan(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r"
                addHistory("tan(${formatResult(value)}${if (isDegMode) "°" else " rad"}) = $r")
            }
            isNewOp = true
        }

        // LOG
        findViewById<Button>(R.id.btn_log).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value <= 0) {
                tvScreen.text = "Error"
                tvExpression.text = "log(${formatResult(value)}) = Error"
            } else {
                val r = formatResult(log10(value)); tvScreen.text = r
                tvExpression.text = "log(${formatResult(value)}) = $r"
                addHistory("log(${formatResult(value)}) = $r")
            }
            isNewOp = true
        }

        // LN
        findViewById<Button>(R.id.btn_ln).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value <= 0) {
                tvScreen.text = "Error"
                tvExpression.text = "ln(${formatResult(value)}) = Error"
            } else {
                val r = formatResult(ln(value)); tvScreen.text = r
                tvExpression.text = "ln(${formatResult(value)}) = $r"
                addHistory("ln(${formatResult(value)}) = $r")
            }
            isNewOp = true
        }

        // SQRT
        findViewById<Button>(R.id.btn_sqrt).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            if (value < 0) {
                tvScreen.text = "Error"
                tvExpression.text = "√(${formatResult(value)}) = Error"
            } else {
                val r = formatResult(sqrt(value)); tvScreen.text = r
                tvExpression.text = "√(${formatResult(value)}) = $r"
                addHistory("√(${formatResult(value)}) = $r")
            }
            isNewOp = true
        }

        // FACTORIAL
        findViewById<Button>(R.id.btn_factorial).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            val n = value.toInt()
            if (n < 0 || n > 20 || value != n.toDouble()) {
                tvScreen.text = "Error"
                tvExpression.text = "${formatResult(value)}! = Error"
            } else {
                var fact = 1L
                for (i in 2..n) fact *= i
                val r = fact.toString(); tvScreen.text = r
                tvExpression.text = "$n! = $r"
                addHistory("$n! = $r")
            }
            isNewOp = true
        }

        // PI
        findViewById<Button>(R.id.btn_pi).setOnClickListener {
            tvScreen.text = formatResult(PI)
            isNewOp = true
        }

        // e
        findViewById<Button>(R.id.btn_e).setOnClickListener {
            tvScreen.text = formatResult(E)
            isNewOp = true
        }
    }

    // ══════════════════════════════════════
    //  EXTRA BUTTONS
    // ══════════════════════════════════════
    private fun setupExtraButtons() {
        // DEG / RAD toggle
        val btnDegRad = findViewById<Button>(R.id.btn_deg_rad)
        btnDegRad.setOnClickListener {
            isDegMode = !isDegMode
            btnDegRad.text = if (isDegMode) "DEG" else "RAD"
            Toast.makeText(this, if (isDegMode) "Degree Mode" else "Radian Mode", Toast.LENGTH_SHORT).show()
        }

        // BACKSPACE
        findViewById<Button>(R.id.btn_backspace).setOnClickListener {
            val current = tvScreen.text.toString()
            if (current.length > 1 && current != "Error") {
                tvScreen.text = current.dropLast(1)
            } else {
                tvScreen.text = "0"
                isNewOp = true
            }
        }

        // PERCENT
        findViewById<Button>(R.id.btn_percent).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            val r = formatResult(value / 100.0)
            tvScreen.text = r
            tvExpression.text = "${formatResult(value)}% = $r"
            addHistory("${formatResult(value)}% = $r")
            isNewOp = true
        }

        // NEGATE (+/-)
        findViewById<Button>(R.id.btn_negate).setOnClickListener {
            val value = getCurrentValue() ?: return@setOnClickListener
            tvScreen.text = formatResult(-value)
        }
    }

    // ══════════════════════════════════════
    //  HISTORY (Dialog)
    // ══════════════════════════════════════
    private fun setupHistory() {
        findViewById<Button>(R.id.btn_history).setOnClickListener {
            showHistoryDialog()
        }
    }

    private fun showHistoryDialog() {
        val builder = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
        builder.setTitle("📝  Calculation History")

        if (historyItems.isEmpty()) {
            builder.setMessage("No calculations yet.\nStart calculating to build your history!")
        } else {
            val scrollView = ScrollView(this)
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 24, 48, 24)
            }

            historyItems.reversed().forEachIndexed { idx, txt ->
                val tv = TextView(this).apply {
                    text = txt
                    textSize = 14f
                    setTextColor(0xFFE0E0E0.toInt())
                    setPadding(0, 16, 0, 16)
                }
                container.addView(tv)
                if (idx < historyItems.size - 1) {
                    val div = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, 1)
                        setBackgroundColor(0xFF424242.toInt())
                    }
                    container.addView(div)
                }
            }
            scrollView.addView(container)
            builder.setView(scrollView)
        }

        builder.setPositiveButton("Close", null)
        builder.setNegativeButton("Clear All") { _, _ ->
            historyItems.clear()
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
        }
        builder.show()
    }

    private fun addHistory(entry: String) {
        if (historyItems.size >= 20) historyItems.removeAt(0)
        historyItems.add(entry)
        try { DatabaseHelper(this).insertLog("Scientific Calculator", entry) } catch (_: Exception) {}
    }

    // ══════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════
    private fun getCurrentValue(): Double? {
        val text = tvScreen.text.toString()
        return if (text == "Error" || text.isEmpty()) null else text.toDoubleOrNull()
    }

    private fun formatResult(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "Error"
        val rounded = Math.round(value * 10000000000.0) / 10000000000.0
        return if (rounded == rounded.toLong().toDouble() && abs(rounded) < 1e15) {
            rounded.toLong().toString()
        } else {
            String.format("%.10g", rounded)
        }
    }
}