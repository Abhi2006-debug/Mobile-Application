package com.example.lab3

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class GeometrySolver : AppCompatActivity() {

    // ── Sections ──
    private lateinit var sectionShapes: LinearLayout
    private lateinit var sectionCoordinate: LinearLayout
    private lateinit var sectionTrig: LinearLayout
    private lateinit var sectionConics: LinearLayout
    private lateinit var sectionTransform: LinearLayout
    private lateinit var sectionTheorems: LinearLayout

    // ── Tab buttons ──
    private lateinit var tabs: List<Button>
    private lateinit var sections: List<LinearLayout>

    // History
    private val historyList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_geometry_solver)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarGeometry)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        // Sections
        sectionShapes = findViewById(R.id.sectionShapes)
        sectionCoordinate = findViewById(R.id.sectionCoordinate)
        sectionTrig = findViewById(R.id.sectionTrig)
        sectionConics = findViewById(R.id.sectionConics)
        sectionTransform = findViewById(R.id.sectionTransform)
        sectionTheorems = findViewById(R.id.sectionTheorems)

        sections = listOf(sectionShapes, sectionCoordinate, sectionTrig, sectionConics, sectionTransform, sectionTheorems)

        // Tabs
        val tabShapes = findViewById<Button>(R.id.tabShapes)
        val tabCoord = findViewById<Button>(R.id.tabCoordinate)
        val tabTrig = findViewById<Button>(R.id.tabTrig)
        val tabConics = findViewById<Button>(R.id.tabConics)
        val tabTransform = findViewById<Button>(R.id.tabTransform)
        val tabTheorems = findViewById<Button>(R.id.tabTheorems)
        tabs = listOf(tabShapes, tabCoord, tabTrig, tabConics, tabTransform, tabTheorems)

        tabs.forEachIndexed { i, btn ->
            btn.setOnClickListener { switchTab(i) }
        }

        // ── Setup each tab ──
        setupShapesTab()
        setupCoordinateTab()
        setupTrigTab()
        setupConicsTab()
        setupTransformTab()
        setupHistory()
    }

    // ══════════════════════════════════════
    //  TAB SWITCHING
    // ══════════════════════════════════════
    private fun switchTab(index: Int) {
        sections.forEachIndexed { i, s -> s.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, b ->
            b.setBackgroundColor(if (i == index) 0xFF1976D2.toInt() else 0xFF0D47A1.toInt())
            b.setTextColor(if (i == index) 0xFFFFFFFF.toInt() else 0xFFB3E5FC.toInt())
        }
    }

    // ══════════════════════════════════════
    //  TAB 1: SHAPES
    // ══════════════════════════════════════
    private fun setupShapesTab() {
        val shapes = arrayOf("Circle", "Rectangle", "Triangle", "Square", "Ellipse",
            "Parallelogram", "Trapezoid", "Sphere", "Cylinder", "Cone")
        val spinner = findViewById<Spinner>(R.id.spinnerShape)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, shapes)

        val labelDim1 = findViewById<TextView>(R.id.labelDim1)
        val labelDim2 = findViewById<TextView>(R.id.labelDim2)
        val labelDim3 = findViewById<TextView>(R.id.labelDim3)
        val etDim1 = findViewById<EditText>(R.id.etDim1)
        val etDim2 = findViewById<EditText>(R.id.etDim2)
        val etDim3 = findViewById<EditText>(R.id.etDim3)
        val tvResult = findViewById<TextView>(R.id.tvShapeResult)
        val tvFormula = findViewById<TextView>(R.id.tvShapeFormula)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                // Reset
                listOf(labelDim2, etDim2, labelDim3, etDim3).forEach { it.visibility = View.GONE }
                tvResult.text = "Enter dimensions and press Calculate"

                when (shapes[pos]) {
                    "Circle" -> { labelDim1.text = "Radius"; tvFormula.text = "Area = πr²\nCircumference = 2πr" }
                    "Rectangle" -> { labelDim1.text = "Length"; show(labelDim2, etDim2); labelDim2.text = "Width"
                        tvFormula.text = "Area = l × w\nPerimeter = 2(l + w)\nDiagonal = √(l² + w²)" }
                    "Triangle" -> { labelDim1.text = "Base"; show(labelDim2, etDim2); labelDim2.text = "Height"
                        show(labelDim3, etDim3); labelDim3.text = "Side c (optional)"
                        tvFormula.text = "Area = ½ × b × h\nPerimeter = a + b + c" }
                    "Square" -> { labelDim1.text = "Side"; tvFormula.text = "Area = s²\nPerimeter = 4s\nDiagonal = s√2" }
                    "Ellipse" -> { labelDim1.text = "Semi-major axis (a)"; show(labelDim2, etDim2); labelDim2.text = "Semi-minor axis (b)"
                        tvFormula.text = "Area = π × a × b\nPerimeter ≈ π[3(a+b) − √((3a+b)(a+3b))]" }
                    "Parallelogram" -> { labelDim1.text = "Base"; show(labelDim2, etDim2); labelDim2.text = "Height"
                        show(labelDim3, etDim3); labelDim3.text = "Side"
                        tvFormula.text = "Area = b × h\nPerimeter = 2(a + b)" }
                    "Trapezoid" -> { labelDim1.text = "Parallel side a"; show(labelDim2, etDim2); labelDim2.text = "Parallel side b"
                        show(labelDim3, etDim3); labelDim3.text = "Height"
                        tvFormula.text = "Area = ½(a + b) × h" }
                    "Sphere" -> { labelDim1.text = "Radius"; tvFormula.text = "Surface Area = 4πr²\nVolume = ⁴⁄₃πr³" }
                    "Cylinder" -> { labelDim1.text = "Radius"; show(labelDim2, etDim2); labelDim2.text = "Height"
                        tvFormula.text = "Surface Area = 2πr(r + h)\nVolume = πr²h\nLateral = 2πrh" }
                    "Cone" -> { labelDim1.text = "Radius"; show(labelDim2, etDim2); labelDim2.text = "Height"
                        tvFormula.text = "Slant = √(r² + h²)\nSurface = πr(r + l)\nVolume = ⅓πr²h" }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCalcShape).setOnClickListener {
            val d1 = etDim1.text.toString().toDoubleOrNull()
            val d2 = etDim2.text.toString().toDoubleOrNull()
            val d3 = etDim3.text.toString().toDoubleOrNull()
            if (d1 == null) { toast("Enter dimension 1"); return@setOnClickListener }

            val unit = getUnit()
            val shape = shapes[spinner.selectedItemPosition]
            val result = when (shape) {
                "Circle" -> "Area = ${fmt(PI * d1 * d1)} $unit²\nCircumference = ${fmt(2 * PI * d1)} $unit"
                "Rectangle" -> { if (d2 == null) { toast("Enter width"); return@setOnClickListener }
                    "Area = ${fmt(d1 * d2)} $unit²\nPerimeter = ${fmt(2 * (d1 + d2))} $unit\nDiagonal = ${fmt(sqrt(d1*d1 + d2*d2))} $unit" }
                "Triangle" -> { if (d2 == null) { toast("Enter height"); return@setOnClickListener }
                    val area = 0.5 * d1 * d2
                    var s = "Area = ${fmt(area)} $unit²"
                    if (d3 != null) s += "\nPerimeter = ${fmt(d1 + d2 + d3)} $unit"
                    s }
                "Square" -> "Area = ${fmt(d1 * d1)} $unit²\nPerimeter = ${fmt(4 * d1)} $unit\nDiagonal = ${fmt(d1 * sqrt(2.0))} $unit"
                "Ellipse" -> { if (d2 == null) { toast("Enter semi-minor axis"); return@setOnClickListener }
                    val area = PI * d1 * d2
                    val perim = PI * (3 * (d1 + d2) - sqrt((3 * d1 + d2) * (d1 + 3 * d2)))
                    "Area = ${fmt(area)} $unit²\nPerimeter ≈ ${fmt(perim)} $unit" }
                "Parallelogram" -> { if (d2 == null) { toast("Enter height"); return@setOnClickListener }
                    var s = "Area = ${fmt(d1 * d2)} $unit²"
                    if (d3 != null) s += "\nPerimeter = ${fmt(2 * (d1 + d3))} $unit"
                    s }
                "Trapezoid" -> { if (d2 == null || d3 == null) { toast("Enter all 3 values"); return@setOnClickListener }
                    "Area = ${fmt(0.5 * (d1 + d2) * d3)} $unit²" }
                "Sphere" -> "Surface Area = ${fmt(4 * PI * d1 * d1)} $unit²\nVolume = ${fmt((4.0/3.0) * PI * d1.pow(3))} $unit³"
                "Cylinder" -> { if (d2 == null) { toast("Enter height"); return@setOnClickListener }
                    val vol = PI * d1 * d1 * d2; val sa = 2 * PI * d1 * (d1 + d2); val lat = 2 * PI * d1 * d2
                    "Volume = ${fmt(vol)} $unit³\nSurface Area = ${fmt(sa)} $unit²\nLateral Area = ${fmt(lat)} $unit²" }
                "Cone" -> { if (d2 == null) { toast("Enter height"); return@setOnClickListener }
                    val slant = sqrt(d1*d1 + d2*d2); val vol = (1.0/3.0) * PI * d1*d1 * d2
                    val sa = PI * d1 * (d1 + slant)
                    "Slant Height = ${fmt(slant)} $unit\nVolume = ${fmt(vol)} $unit³\nSurface Area = ${fmt(sa)} $unit²" }
                else -> "—"
            }
            tvResult.text = result
            addHistory("[$shape] $result")
        }
    }

    // ══════════════════════════════════════
    //  TAB 2: COORDINATE GEOMETRY
    // ══════════════════════════════════════
    private fun setupCoordinateTab() {
        val ops = arrayOf("Distance", "Midpoint", "Slope", "Line Equation", "Section Formula", "Area of Triangle")
        val spinner = findViewById<Spinner>(R.id.spinnerCoordOp)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ops)

        val labelC = findViewById<TextView>(R.id.labelPointC)
        val layoutC = findViewById<LinearLayout>(R.id.layoutPointC)
        val layoutRatio = findViewById<LinearLayout>(R.id.layoutRatio)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                labelC.visibility = View.GONE; layoutC.visibility = View.GONE; layoutRatio.visibility = View.GONE
                when (ops[pos]) {
                    "Section Formula" -> { layoutRatio.visibility = View.VISIBLE }
                    "Area of Triangle" -> { labelC.visibility = View.VISIBLE; layoutC.visibility = View.VISIBLE }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCalcCoord).setOnClickListener {
            val x1 = etVal(R.id.etX1); val y1 = etVal(R.id.etY1)
            val x2 = etVal(R.id.etX2); val y2 = etVal(R.id.etY2)
            if (x1 == null || y1 == null || x2 == null || y2 == null) { toast("Enter both points"); return@setOnClickListener }

            val tv = findViewById<TextView>(R.id.tvCoordResult)
            val op = ops[spinner.selectedItemPosition]
            val result = when (op) {
                "Distance" -> {
                    val d = sqrt((x2-x1).pow(2) + (y2-y1).pow(2))
                    "Distance = √[(${fmt(x2)}−${fmt(x1)})² + (${fmt(y2)}−${fmt(y1)})²]\n= ${fmt(d)}" }
                "Midpoint" -> {
                    "Midpoint = ((${fmt(x1)}+${fmt(x2)})/2, (${fmt(y1)}+${fmt(y2)})/2)\n= (${fmt((x1+x2)/2)}, ${fmt((y1+y2)/2)})" }
                "Slope" -> {
                    if (x2 == x1) "Slope is undefined (vertical line)"
                    else { val m = (y2 - y1) / (x2 - x1); "Slope m = (${fmt(y2)}−${fmt(y1)})/(${fmt(x2)}−${fmt(x1)})\n= ${fmt(m)}" } }
                "Line Equation" -> {
                    if (x2 == x1) "x = ${fmt(x1)} (vertical line)"
                    else { val m = (y2-y1)/(x2-x1); val b = y1 - m*x1
                        "Slope m = ${fmt(m)}\ny − ${fmt(y1)} = ${fmt(m)}(x − ${fmt(x1)})\ny = ${fmt(m)}x + ${fmt(b)}" } }
                "Section Formula" -> {
                    val rm = etVal(R.id.etRatioM); val rn = etVal(R.id.etRatioN)
                    if (rm == null || rn == null) { toast("Enter ratio m:n"); return@setOnClickListener }
                    val px = (rm*x2 + rn*x1)/(rm+rn); val py = (rm*y2 + rn*y1)/(rm+rn)
                    "P divides AB in ratio ${fmt(rm)}:${fmt(rn)}\nP = (${fmt(px)}, ${fmt(py)})" }
                "Area of Triangle" -> {
                    val x3 = etVal(R.id.etX3); val y3 = etVal(R.id.etY3)
                    if (x3 == null || y3 == null) { toast("Enter point C"); return@setOnClickListener }
                    val area = abs(x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2)) / 2.0
                    "Area = ½|x₁(y₂−y₃) + x₂(y₃−y₁) + x₃(y₁−y₂)|\n= ${fmt(area)} sq units" }
                else -> "—"
            }
            tv.text = result
            addHistory("[$op] $result")
        }
    }

    // ══════════════════════════════════════
    //  TAB 3: TRIGONOMETRY
    // ══════════════════════════════════════
    private fun setupTrigTab() {
        val ops = arrayOf("sin / cos / tan", "Inverse Trig (arcsin/cos/tan)", "Degrees → Radians",
            "Radians → Degrees", "Law of Cosines (find side c)", "Law of Sines (find angle B)")
        val spinner = findViewById<Spinner>(R.id.spinnerTrigOp)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ops)

        val label1 = findViewById<TextView>(R.id.labelTrig1)
        val label2 = findViewById<TextView>(R.id.labelTrig2)
        val label3 = findViewById<TextView>(R.id.labelTrig3)
        val et2 = findViewById<EditText>(R.id.etTrig2)
        val et3 = findViewById<EditText>(R.id.etTrig3)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                listOf(label2, et2, label3, et3).forEach { it.visibility = View.GONE }
                when (pos) {
                    0 -> label1.text = "Angle (degrees)"
                    1 -> label1.text = "Value (−1 to 1 for arcsin/arccos)"
                    2 -> label1.text = "Angle in Degrees"
                    3 -> label1.text = "Angle in Radians"
                    4 -> { label1.text = "Side a"; show(label2, et2); label2.text = "Side b"
                        show(label3, et3); label3.text = "Angle C (degrees)" }
                    5 -> { label1.text = "Side a"; show(label2, et2); label2.text = "Side b"
                        show(label3, et3); label3.text = "Angle A (degrees)" }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCalcTrig).setOnClickListener {
            val v1 = etVal(R.id.etTrig1) ?: run { toast("Enter a value"); return@setOnClickListener }
            val tv = findViewById<TextView>(R.id.tvTrigResult)
            val op = ops[spinner.selectedItemPosition]

            val result = when (spinner.selectedItemPosition) {
                0 -> { val rad = Math.toRadians(v1)
                    "sin(${fmt(v1)}°) = ${fmt(sin(rad))}\ncos(${fmt(v1)}°) = ${fmt(cos(rad))}\ntan(${fmt(v1)}°) = ${fmt(tan(rad))}" }
                1 -> { val asin = if (abs(v1) <= 1) fmt(Math.toDegrees(asin(v1))) else "N/A"
                    val acos = if (abs(v1) <= 1) fmt(Math.toDegrees(acos(v1))) else "N/A"
                    val atan = fmt(Math.toDegrees(atan(v1)))
                    "arcsin(${fmt(v1)}) = $asin°\narccos(${fmt(v1)}) = $acos°\narctan(${fmt(v1)}) = $atan°" }
                2 -> "Radians = ${fmt(v1)} × π/180\n= ${fmt(Math.toRadians(v1))} rad"
                3 -> "Degrees = ${fmt(v1)} × 180/π\n= ${fmt(Math.toDegrees(v1))}°"
                4 -> { val a = v1; val b = etVal(R.id.etTrig2); val cDeg = etVal(R.id.etTrig3)
                    if (b == null || cDeg == null) { toast("Enter all values"); return@setOnClickListener }
                    val cRad = Math.toRadians(cDeg)
                    val c = sqrt(a*a + b*b - 2*a*b*cos(cRad))
                    "Law of Cosines: c² = a² + b² − 2ab·cos(C)\nc = √(${fmt(a)}² + ${fmt(b)}² − 2·${fmt(a)}·${fmt(b)}·cos(${fmt(cDeg)}°))\nc = ${fmt(c)}" }
                5 -> { val a = v1; val b = etVal(R.id.etTrig2); val aDeg = etVal(R.id.etTrig3)
                    if (b == null || aDeg == null) { toast("Enter all values"); return@setOnClickListener }
                    val aRad = Math.toRadians(aDeg)
                    val sinB = b * sin(aRad) / a
                    if (abs(sinB) > 1) "No valid angle (sinB > 1)"
                    else { val bDeg = Math.toDegrees(asin(sinB))
                        "Law of Sines: a/sinA = b/sinB\nsinB = b·sinA / a = ${fmt(b)}·sin(${fmt(aDeg)}°)/${fmt(a)}\nB = ${fmt(bDeg)}°" } }
                else -> "—"
            }
            tv.text = result
            addHistory("[$op] $result")
        }
    }

    // ══════════════════════════════════════
    //  TAB 4: CONICS
    // ══════════════════════════════════════
    private fun setupConicsTab() {
        val types = arrayOf("Parabola (y² = 4ax)", "Parabola (x² = 4ay)",
            "Ellipse (x²/a² + y²/b² = 1)", "Hyperbola (x²/a² − y²/b² = 1)")
        val spinner = findViewById<Spinner>(R.id.spinnerConic)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)

        val label1 = findViewById<TextView>(R.id.labelConic1)
        val label2 = findViewById<TextView>(R.id.labelConic2)
        val et2 = findViewById<EditText>(R.id.etConic2)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                when (pos) {
                    0, 1 -> { label1.text = "Value of a"; label2.visibility = View.GONE; et2.visibility = View.GONE }
                    2, 3 -> { label1.text = "Semi-major a"; label2.text = "Semi-minor b"
                        label2.visibility = View.VISIBLE; et2.visibility = View.VISIBLE }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCalcConic).setOnClickListener {
            val a = etVal(R.id.etConic1) ?: run { toast("Enter value of a"); return@setOnClickListener }
            val tv = findViewById<TextView>(R.id.tvConicResult)

            val result = when (spinner.selectedItemPosition) {
                0 -> "Vertex: (0, 0)\nFocus: (${fmt(a)}, 0)\nDirectrix: x = ${fmt(-a)}\nLatus Rectum = ${fmt(4*a)}\nEccentricity = 1"
                1 -> "Vertex: (0, 0)\nFocus: (0, ${fmt(a)})\nDirectrix: y = ${fmt(-a)}\nLatus Rectum = ${fmt(4*a)}\nEccentricity = 1"
                2 -> { val b = etVal(R.id.etConic2) ?: run { toast("Enter b"); return@setOnClickListener }
                    val c = sqrt(abs(a*a - b*b)); val e = c / a
                    "Center: (0, 0)\nVertices: (±${fmt(a)}, 0)\nFoci: (±${fmt(c)}, 0)\nEccentricity = ${fmt(e)}\nArea = ${fmt(PI*a*b)}" }
                3 -> { val b = etVal(R.id.etConic2) ?: run { toast("Enter b"); return@setOnClickListener }
                    val c = sqrt(a*a + b*b); val e = c / a
                    "Center: (0, 0)\nVertices: (±${fmt(a)}, 0)\nFoci: (±${fmt(c)}, 0)\nEccentricity = ${fmt(e)}\nAsymptotes: y = ±(${fmt(b/a)})x" }
                else -> "—"
            }
            tv.text = result
            addHistory("[Conics] $result")
        }
    }

    // ══════════════════════════════════════
    //  TAB 5: TRANSFORMATIONS
    // ══════════════════════════════════════
    private fun setupTransformTab() {
        val ops = arrayOf("Rotation about Origin", "Translation", "Scaling",
            "Reflect about X-axis", "Reflect about Y-axis", "Reflect about Origin", "Reflect about y = x")
        val spinner = findViewById<Spinner>(R.id.spinnerTransform)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ops)

        val labelP = findViewById<TextView>(R.id.labelTfParam)
        val etP = findViewById<EditText>(R.id.etTfParam)
        val labelP2 = findViewById<TextView>(R.id.labelTfParam2)
        val etP2 = findViewById<EditText>(R.id.etTfParam2)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                labelP.visibility = View.VISIBLE; etP.visibility = View.VISIBLE
                labelP2.visibility = View.GONE; etP2.visibility = View.GONE
                when (pos) {
                    0 -> labelP.text = "Angle θ (degrees)"
                    1 -> { labelP.text = "dx (shift X)"; show(labelP2, etP2); labelP2.text = "dy (shift Y)" }
                    2 -> { labelP.text = "sx (scale X)"; show(labelP2, etP2); labelP2.text = "sy (scale Y)" }
                    else -> { labelP.visibility = View.GONE; etP.visibility = View.GONE }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCalcTransform).setOnClickListener {
            val x = etVal(R.id.etTfX); val y = etVal(R.id.etTfY)
            if (x == null || y == null) { toast("Enter point (x, y)"); return@setOnClickListener }
            val tv = findViewById<TextView>(R.id.tvTransformResult)

            val result = when (spinner.selectedItemPosition) {
                0 -> { val th = etVal(R.id.etTfParam) ?: run { toast("Enter angle"); return@setOnClickListener }
                    val rad = Math.toRadians(th)
                    val nx = x*cos(rad) - y*sin(rad); val ny = x*sin(rad) + y*cos(rad)
                    "Rotation by ${fmt(th)}°:\nx' = x·cos(θ) − y·sin(θ) = ${fmt(nx)}\ny' = x·sin(θ) + y·cos(θ) = ${fmt(ny)}\n\nResult: (${fmt(nx)}, ${fmt(ny)})" }
                1 -> { val dx = etVal(R.id.etTfParam) ?: 0.0; val dy = etVal(R.id.etTfParam2) ?: 0.0
                    "Translation by (${fmt(dx)}, ${fmt(dy)}):\nx' = ${fmt(x)} + ${fmt(dx)} = ${fmt(x+dx)}\ny' = ${fmt(y)} + ${fmt(dy)} = ${fmt(y+dy)}\n\nResult: (${fmt(x+dx)}, ${fmt(y+dy)})" }
                2 -> { val sx = etVal(R.id.etTfParam) ?: 1.0; val sy = etVal(R.id.etTfParam2) ?: 1.0
                    "Scaling by (${fmt(sx)}, ${fmt(sy)}):\nx' = ${fmt(sx)} × ${fmt(x)} = ${fmt(sx*x)}\ny' = ${fmt(sy)} × ${fmt(y)} = ${fmt(sy*y)}\n\nResult: (${fmt(sx*x)}, ${fmt(sy*y)})" }
                3 -> "Reflect about X-axis:\n(${fmt(x)}, ${fmt(y)}) → (${fmt(x)}, ${fmt(-y)})"
                4 -> "Reflect about Y-axis:\n(${fmt(x)}, ${fmt(y)}) → (${fmt(-x)}, ${fmt(y)})"
                5 -> "Reflect about Origin:\n(${fmt(x)}, ${fmt(y)}) → (${fmt(-x)}, ${fmt(-y)})"
                6 -> "Reflect about y = x:\n(${fmt(x)}, ${fmt(y)}) → (${fmt(y)}, ${fmt(x)})"
                else -> "—"
            }
            tv.text = result
            addHistory("[Transform] $result")
        }
    }

    // ══════════════════════════════════════
    //  HISTORY
    // ══════════════════════════════════════
    private fun setupHistory() {
        val sw = findViewById<Switch>(R.id.switchHistory)
        val status = findViewById<TextView>(R.id.tvHistoryStatus)
        val list = findViewById<LinearLayout>(R.id.layoutHistoryList)

        sw.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                status.text = "History is ON — last 10 calculations"
                list.visibility = View.VISIBLE
                refreshHistory(list)
            } else {
                status.text = "Keep a log of all your calculations"
                list.visibility = View.GONE
            }
        }
    }

    private fun addHistory(entry: String) {
        if (historyList.size >= 10) historyList.removeAt(0)
        historyList.add(entry)
        try { DatabaseHelper(this).insertLog("Geometry", entry) } catch (_: Exception) {}
        val sw = findViewById<Switch>(R.id.switchHistory)
        if (sw.isChecked) refreshHistory(findViewById(R.id.layoutHistoryList))
    }

    private fun refreshHistory(container: LinearLayout) {
        container.removeAllViews()
        historyList.reversed().forEach { txt ->
            val tv = TextView(this).apply {
                text = txt; textSize = 12f; setTextColor(0xFF5F6368.toInt())
                setPadding(0, 8, 0, 8)
            }
            container.addView(tv)
            val div = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(0xFFE8EAED.toInt())
            }
            container.addView(div)
        }
    }

    // ══════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════
    private fun fmt(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.4f", v)
    private fun etVal(id: Int): Double? = findViewById<EditText>(id).text.toString().toDoubleOrNull()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun show(vararg views: View) { views.forEach { it.visibility = View.VISIBLE } }
    private fun getUnit(): String {
        val rg = findViewById<RadioGroup>(R.id.rgUnit)
        return when (rg.checkedRadioButtonId) {
            R.id.rbCm -> "cm"; R.id.rbM -> "m"; R.id.rbInch -> "in"; R.id.rbFt -> "ft"; else -> ""
        }
    }
}