package com.example.lab3

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FormulaDashboardActivity : AppCompatActivity() {

    private val allFormulas = listOf(
        // ── Algebra ──
        Formula("Quadratic Formula", "x = [-b ± √(b²-4ac)] / 2a", "Algebra", "Solves ax² + bx + c = 0"),
        Formula("Linear Equation", "y = mx + b", "Algebra", "Slope-intercept form of a straight line"),
        Formula("Binomial Theorem", "(a+b)ⁿ = Σ C(n,k)·aⁿ⁻ᵏ·bᵏ", "Algebra", "Expansion of binomial raised to power n"),
        Formula("Difference of Squares", "a² - b² = (a+b)(a-b)", "Algebra", "Factoring identity for two squares"),
        Formula("Sum of AP", "S = n/2 · [2a + (n-1)d]", "Algebra", "Sum of first n terms of arithmetic progression"),
        Formula("Sum of GP", "S = a(rⁿ - 1) / (r - 1)", "Algebra", "Sum of first n terms of geometric progression"),

        // ── Geometry ──
        Formula("Pythagorean Theorem", "a² + b² = c²", "Geometry", "Relation between sides of a right triangle"),
        Formula("Area of Circle", "A = πr²", "Geometry", "Area enclosed by a circle of radius r"),
        Formula("Area of Triangle", "A = ½ · b · h", "Geometry", "Base times height divided by 2"),
        Formula("Heron's Formula", "A = √[s(s-a)(s-b)(s-c)]", "Geometry", "Area using semi-perimeter s = (a+b+c)/2"),
        Formula("Volume of Sphere", "V = (4/3)πr³", "Geometry", "Volume of a sphere of radius r"),
        Formula("Distance Formula", "d = √[(x₂-x₁)² + (y₂-y₁)²]", "Geometry", "Distance between two points in 2D"),

        // ── Trigonometry ──
        Formula("Sine Rule", "a/sinA = b/sinB = c/sinC", "Trigonometry", "Relates sides to opposite angles"),
        Formula("Cosine Rule", "c² = a² + b² - 2ab·cosC", "Trigonometry", "Generalized Pythagorean theorem"),
        Formula("sin²θ + cos²θ", "sin²θ + cos²θ = 1", "Trigonometry", "Fundamental Pythagorean identity"),
        Formula("Double Angle (sin)", "sin2θ = 2·sinθ·cosθ", "Trigonometry", "Sine of double angle"),
        Formula("Double Angle (cos)", "cos2θ = cos²θ - sin²θ", "Trigonometry", "Cosine of double angle"),

        // ── Calculus ──
        Formula("Power Rule", "d/dx [xⁿ] = n·xⁿ⁻¹", "Calculus", "Derivative of x raised to power n"),
        Formula("Chain Rule", "d/dx [f(g(x))] = f'(g(x))·g'(x)", "Calculus", "Derivative of composite functions"),
        Formula("Integration (Power)", "∫xⁿ dx = xⁿ⁺¹/(n+1) + C", "Calculus", "Anti-derivative of power function"),
        Formula("Integration by Parts", "∫u·dv = uv - ∫v·du", "Calculus", "Product rule for integration"),

        // ── Physics ──
        Formula("Newton's 2nd Law", "F = ma", "Physics", "Force equals mass times acceleration"),
        Formula("Einstein's E=mc²", "E = mc²", "Physics", "Mass-energy equivalence"),
        Formula("Ohm's Law", "V = IR", "Physics", "Voltage = Current × Resistance"),
        Formula("Kinematic Eq.", "v² = u² + 2as", "Physics", "Final velocity from initial velocity, acceleration, displacement"),
        Formula("Gravitational Force", "F = G·m₁m₂/r²", "Physics", "Newton's law of universal gravitation"),

        // ── Statistics ──
        Formula("Mean", "μ = Σxᵢ / n", "Statistics", "Average of all values"),
        Formula("Standard Deviation", "σ = √[Σ(xᵢ-μ)²/n]", "Statistics", "Measure of data spread from the mean"),
        Formula("Variance", "σ² = Σ(xᵢ-μ)² / n", "Statistics", "Square of standard deviation"),
        Formula("Permutation", "P(n,r) = n! / (n-r)!", "Statistics", "Ordered arrangements of r items from n"),
        Formula("Combination", "C(n,r) = n! / [r!(n-r)!]", "Statistics", "Unordered selections of r items from n")
    )

    private lateinit var formulaAdapter: FormulaAdapter
    private lateinit var tvListTitle: TextView
    private var activeCategory = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formula_dashboard)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarFormula)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        tvListTitle = findViewById(R.id.tv_list_title)

        // RecyclerView
        val rv = findViewById<RecyclerView>(R.id.rv_formula_list)
        rv.layoutManager = LinearLayoutManager(this)
        formulaAdapter = FormulaAdapter(allFormulas) { formula ->
            try {
                val db = DatabaseHelper(this)
                db.insertLog("Formula Reference", "Viewed: ${formula.name}")
            } catch (_: Exception) {}
            Toast.makeText(this, "${formula.name}\n${formula.equation}", Toast.LENGTH_LONG).show()
        }
        rv.adapter = formulaAdapter
        updateTitle(allFormulas.size)

        // ── Category chips ──
        val chipMap = mapOf(
            R.id.chipAll to "All",
            R.id.chipAlgebra to "Algebra",
            R.id.chipGeometry to "Geometry",
            R.id.chipTrig to "Trigonometry",
            R.id.chipCalculus to "Calculus",
            R.id.chipPhysics to "Physics",
            R.id.chipStats to "Statistics"
        )

        val chipButtons = chipMap.keys.map { findViewById<Button>(it) }

        for ((id, category) in chipMap) {
            findViewById<Button>(id).setOnClickListener {
                activeCategory = category
                // Highlight active chip
                chipButtons.forEach { btn ->
                    btn.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF16213E.toInt())
                    btn.setTextColor(0xFF90CAF9.toInt())
                }
                val active = findViewById<Button>(id)
                active.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1565C0.toInt())
                active.setTextColor(0xFFFFFFFF.toInt())

                applyFilter(findViewById<EditText>(R.id.etSearch).text.toString())
            }
        }

        // ── Search ──
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter(s.toString()) }
        })
    }

    private fun applyFilter(query: String) {
        var list = if (activeCategory == "All") allFormulas
                   else allFormulas.filter { it.category == activeCategory }

        if (query.isNotBlank()) {
            val q = query.lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) ||
                it.equation.lowercase().contains(q) ||
                it.description.lowercase().contains(q)
            }
        }
        formulaAdapter.updateData(list)
        updateTitle(list.size)
    }

    private fun updateTitle(count: Int) {
        val label = if (activeCategory == "All") "All Formulas" else "$activeCategory Formulas"
        tvListTitle.text = "$label  •  $count results"
    }
}