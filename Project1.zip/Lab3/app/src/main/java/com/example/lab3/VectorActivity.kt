package com.example.lab3

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class VectorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vector)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarVec)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        // Inputs
        val ax = findViewById<EditText>(R.id.et_ax)
        val ay = findViewById<EditText>(R.id.et_ay)
        val az = findViewById<EditText>(R.id.et_az)
        val bx = findViewById<EditText>(R.id.et_bx)
        val by = findViewById<EditText>(R.id.et_by)
        val bz = findViewById<EditText>(R.id.et_bz)
        val tvResult = findViewById<TextView>(R.id.tv_result_vec)

        // ── DOT PRODUCT ──
        findViewById<Button>(R.id.btn_dot).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val dot = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
            val result = "Dot Product (A · B)\n\n" +
                    "= (${fmt(a[0])})(${fmt(b[0])}) + (${fmt(a[1])})(${fmt(b[1])}) + (${fmt(a[2])})(${fmt(b[2])})\n" +
                    "= ${fmt(dot)}"
            tvResult.text = result
            log("Dot Product: ${fmtVec(a)}·${fmtVec(b)} = ${fmt(dot)}")
        }

        // ── CROSS PRODUCT ──
        findViewById<Button>(R.id.btn_cross).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val cx = a[1]*b[2] - a[2]*b[1]
            val cy = a[2]*b[0] - a[0]*b[2]
            val cz = a[0]*b[1] - a[1]*b[0]
            val result = "Cross Product (A × B)\n\n" +
                    "= │ i    j    k  │\n" +
                    "  │ ${fmt(a[0])}  ${fmt(a[1])}  ${fmt(a[2])} │\n" +
                    "  │ ${fmt(b[0])}  ${fmt(b[1])}  ${fmt(b[2])} │\n\n" +
                    "= ${fmt(cx)}i + ${fmt(cy)}j + ${fmt(cz)}k"
            tvResult.text = result
            log("Cross Product: ${fmtVec(a)}×${fmtVec(b)} = (${fmt(cx)},${fmt(cy)},${fmt(cz)})")
        }

        // ── ADD ──
        findViewById<Button>(R.id.btn_add).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val r = doubleArrayOf(a[0]+b[0], a[1]+b[1], a[2]+b[2])
            tvResult.text = "Vector Addition (A + B)\n\n= ${fmt(r[0])}i + ${fmt(r[1])}j + ${fmt(r[2])}k"
            log("Add: ${fmtVec(a)}+${fmtVec(b)} = ${fmtVec(r)}")
        }

        // ── SUBTRACT ──
        findViewById<Button>(R.id.btn_sub).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val r = doubleArrayOf(a[0]-b[0], a[1]-b[1], a[2]-b[2])
            tvResult.text = "Vector Subtraction (A − B)\n\n= ${fmt(r[0])}i + ${fmt(r[1])}j + ${fmt(r[2])}k"
            log("Subtract: ${fmtVec(a)}-${fmtVec(b)} = ${fmtVec(r)}")
        }

        // ── MAGNITUDES ──
        findViewById<Button>(R.id.btn_mag).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val magA = sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2])
            val magB = sqrt(b[0]*b[0] + b[1]*b[1] + b[2]*b[2])

            val sb = StringBuilder("Magnitudes\n\n")
            sb.appendLine("|A| = √(${fmt(a[0])}² + ${fmt(a[1])}² + ${fmt(a[2])}²)")
            sb.appendLine("    = ${fmt(magA)}")
            sb.appendLine()
            sb.appendLine("|B| = √(${fmt(b[0])}² + ${fmt(b[1])}² + ${fmt(b[2])}²)")
            sb.appendLine("    = ${fmt(magB)}")

            // Unit vectors
            if (magA > 0) {
                sb.appendLine()
                sb.appendLine("Unit â = (${fmt(a[0]/magA)}, ${fmt(a[1]/magA)}, ${fmt(a[2]/magA)})")
            }
            if (magB > 0) {
                sb.appendLine("Unit b̂ = (${fmt(b[0]/magB)}, ${fmt(b[1]/magB)}, ${fmt(b[2]/magB)})")
            }

            tvResult.text = sb.toString()
            log("Magnitudes: |A|=${fmt(magA)}, |B|=${fmt(magB)}")
        }

        // ── ANGLE ──
        findViewById<Button>(R.id.btn_angle).setOnClickListener {
            val (a, b) = readVectors(ax, ay, az, bx, by, bz) ?: return@setOnClickListener
            val dot = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
            val magA = sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2])
            val magB = sqrt(b[0]*b[0] + b[1]*b[1] + b[2]*b[2])

            if (magA == 0.0 || magB == 0.0) {
                tvResult.text = "Cannot find angle — one vector is zero"
                return@setOnClickListener
            }

            val cosTheta = (dot / (magA * magB)).coerceIn(-1.0, 1.0)
            val angleRad = acos(cosTheta)
            val angleDeg = Math.toDegrees(angleRad)

            val sb = StringBuilder("Angle Between A and B\n\n")
            sb.appendLine("cos θ = (A·B) / (|A| × |B|)")
            sb.appendLine("      = ${fmt(dot)} / (${fmt(magA)} × ${fmt(magB)})")
            sb.appendLine("      = ${fmt(cosTheta)}")
            sb.appendLine()
            sb.appendLine("θ = ${fmt(angleDeg)}°")
            sb.appendLine("  = ${fmt(angleRad)} rad")
            sb.appendLine()
            when {
                angleDeg < 0.01 -> sb.appendLine("Vectors are parallel (same direction)")
                abs(angleDeg - 180.0) < 0.01 -> sb.appendLine("Vectors are anti-parallel")
                abs(angleDeg - 90.0) < 0.01 -> sb.appendLine("Vectors are perpendicular ⊥")
                angleDeg < 90 -> sb.appendLine("Vectors form an acute angle")
                else -> sb.appendLine("Vectors form an obtuse angle")
            }

            tvResult.text = sb.toString()
            log("Angle: ${fmtVec(a)} ∠ ${fmtVec(b)} = ${fmt(angleDeg)}°")
        }
    }

    // ══════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════
    private fun readVectors(ax: EditText, ay: EditText, az: EditText,
                            bx: EditText, by: EditText, bz: EditText): Pair<DoubleArray, DoubleArray>? {
        val fields = listOf(ax, ay, az, bx, by, bz)
        for (et in fields) {
            if (et.text.isEmpty()) {
                Toast.makeText(this, "Fill all fields (use 0 for empty)", Toast.LENGTH_SHORT).show()
                return null
            }
        }
        return Pair(
            doubleArrayOf(ax.text.toString().toDouble(), ay.text.toString().toDouble(), az.text.toString().toDouble()),
            doubleArrayOf(bx.text.toString().toDouble(), by.text.toString().toDouble(), bz.text.toString().toDouble())
        )
    }

    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble() && abs(v) < 1e15) v.toLong().toString()
        else String.format("%.4f", v)
    }

    private fun fmtVec(v: DoubleArray) = "(${fmt(v[0])},${fmt(v[1])},${fmt(v[2])})"

    private fun log(details: String) {
        try { DatabaseHelper(this).insertLog("Vector", details) } catch (_: Exception) {}
    }
}