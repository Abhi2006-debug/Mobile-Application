package com.example.lab3

import android.content.res.ColorStateList
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ConverterActivity : AppCompatActivity() {

    private val categories = mapOf(
        "Length" to arrayOf(
            "Meters → Kilometers", "Kilometers → Meters",
            "Miles → Kilometers", "Kilometers → Miles",
            "Feet → Meters", "Meters → Feet",
            "Inches → Centimeters", "Centimeters → Inches"
        ),
        "Weight" to arrayOf(
            "Kilograms → Pounds", "Pounds → Kilograms",
            "Grams → Ounces", "Ounces → Grams",
            "Kilograms → Grams", "Grams → Kilograms"
        ),
        "Temperature" to arrayOf(
            "Celsius → Fahrenheit", "Fahrenheit → Celsius",
            "Celsius → Kelvin", "Kelvin → Celsius"
        ),
        "Speed" to arrayOf(
            "km/h → m/s", "m/s → km/h",
            "mph → km/h", "km/h → mph",
            "Knots → km/h", "km/h → Knots"
        ),
        "Area" to arrayOf(
            "m² → ft²", "ft² → m²",
            "Acres → m²", "m² → Acres",
            "Hectares → Acres", "Acres → Hectares"
        )
    )

    private var activeCategory = "Length"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_converter)

        // Toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarConv)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val spinner = findViewById<Spinner>(R.id.spinner_units)
        val etValue = findViewById<EditText>(R.id.et_value)
        val btnConvert = findViewById<Button>(R.id.btn_convert)
        val tvResult = findViewById<TextView>(R.id.tv_result_conv)
        val tvDetail = findViewById<TextView>(R.id.tv_result_detail)

        // ── Category chips ──
        val chipMap = mapOf(
            R.id.chipLength to "Length",
            R.id.chipWeight to "Weight",
            R.id.chipTemp to "Temperature",
            R.id.chipSpeed to "Speed",
            R.id.chipArea to "Area"
        )
        val chipButtons = chipMap.keys.map { findViewById<Button>(it) }

        fun updateSpinner(category: String) {
            activeCategory = category
            val opts = categories[category] ?: return
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)

            chipButtons.forEach { btn ->
                btn.backgroundTintList = ColorStateList.valueOf(0xFF16213E.toInt())
                btn.setTextColor(0xFF90CAF9.toInt())
            }
            val activeBtn = chipMap.entries.find { it.value == category }?.key?.let { findViewById<Button>(it) }
            activeBtn?.backgroundTintList = ColorStateList.valueOf(0xFF1565C0.toInt())
            activeBtn?.setTextColor(0xFFFFFFFF.toInt())
        }

        for ((id, cat) in chipMap) {
            findViewById<Button>(id).setOnClickListener { updateSpinner(cat) }
        }

        updateSpinner("Length")

        // ── Convert ──
        btnConvert.setOnClickListener {
            val inputStr = etValue.text.toString()
            if (inputStr.isEmpty()) {
                Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val input = inputStr.toDoubleOrNull()
            if (input == null) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selected = spinner.selectedItem.toString()
            val (result, formula) = convert(selected, input)

            tvResult.text = fmt(result)
            tvDetail.text = "$inputStr $formula"

            try { DatabaseHelper(this).insertLog("Converter", "$selected: $input → ${fmt(result)}") } catch (_: Exception) {}
        }
    }

    private fun convert(op: String, v: Double): Pair<Double, String> {
        return when (op) {
            // Length
            "Meters → Kilometers"    -> Pair(v / 1000,     "m  =  ${fmt(v/1000)} km")
            "Kilometers → Meters"    -> Pair(v * 1000,     "km  =  ${fmt(v*1000)} m")
            "Miles → Kilometers"     -> Pair(v * 1.60934,  "mi  =  ${fmt(v*1.60934)} km")
            "Kilometers → Miles"     -> Pair(v / 1.60934,  "km  =  ${fmt(v/1.60934)} mi")
            "Feet → Meters"          -> Pair(v * 0.3048,   "ft  =  ${fmt(v*0.3048)} m")
            "Meters → Feet"          -> Pair(v / 0.3048,   "m  =  ${fmt(v/0.3048)} ft")
            "Inches → Centimeters"   -> Pair(v * 2.54,     "in  =  ${fmt(v*2.54)} cm")
            "Centimeters → Inches"   -> Pair(v / 2.54,     "cm  =  ${fmt(v/2.54)} in")
            // Weight
            "Kilograms → Pounds"     -> Pair(v * 2.20462,  "kg  =  ${fmt(v*2.20462)} lbs")
            "Pounds → Kilograms"     -> Pair(v / 2.20462,  "lbs  =  ${fmt(v/2.20462)} kg")
            "Grams → Ounces"         -> Pair(v * 0.035274, "g  =  ${fmt(v*0.035274)} oz")
            "Ounces → Grams"         -> Pair(v / 0.035274, "oz  =  ${fmt(v/0.035274)} g")
            "Kilograms → Grams"      -> Pair(v * 1000,     "kg  =  ${fmt(v*1000)} g")
            "Grams → Kilograms"      -> Pair(v / 1000,     "g  =  ${fmt(v/1000)} kg")
            // Temperature
            "Celsius → Fahrenheit"   -> Pair(v * 9.0/5 + 32,       "°C  =  ${fmt(v*9.0/5+32)} °F")
            "Fahrenheit → Celsius"   -> Pair((v - 32) * 5.0/9,     "°F  =  ${fmt((v-32)*5.0/9)} °C")
            "Celsius → Kelvin"       -> Pair(v + 273.15,           "°C  =  ${fmt(v+273.15)} K")
            "Kelvin → Celsius"       -> Pair(v - 273.15,           "K  =  ${fmt(v-273.15)} °C")
            // Speed
            "km/h → m/s"             -> Pair(v / 3.6,       "km/h  =  ${fmt(v/3.6)} m/s")
            "m/s → km/h"             -> Pair(v * 3.6,       "m/s  =  ${fmt(v*3.6)} km/h")
            "mph → km/h"             -> Pair(v * 1.60934,   "mph  =  ${fmt(v*1.60934)} km/h")
            "km/h → mph"             -> Pair(v / 1.60934,   "km/h  =  ${fmt(v/1.60934)} mph")
            "Knots → km/h"           -> Pair(v * 1.852,     "kn  =  ${fmt(v*1.852)} km/h")
            "km/h → Knots"           -> Pair(v / 1.852,     "km/h  =  ${fmt(v/1.852)} kn")
            // Area
            "m² → ft²"              -> Pair(v * 10.7639,   "m²  =  ${fmt(v*10.7639)} ft²")
            "ft² → m²"              -> Pair(v / 10.7639,   "ft²  =  ${fmt(v/10.7639)} m²")
            "Acres → m²"            -> Pair(v * 4046.86,   "ac  =  ${fmt(v*4046.86)} m²")
            "m² → Acres"            -> Pair(v / 4046.86,   "m²  =  ${fmt(v/4046.86)} ac")
            "Hectares → Acres"      -> Pair(v * 2.47105,   "ha  =  ${fmt(v*2.47105)} ac")
            "Acres → Hectares"      -> Pair(v / 2.47105,   "ac  =  ${fmt(v/2.47105)} ha")
            else -> Pair(0.0, "Unknown")
        }
    }

    private fun fmt(v: Double): String {
        return if (v == v.toLong().toDouble() && kotlin.math.abs(v) < 1e15) v.toLong().toString()
        else String.format("%.4f", v)
    }
}