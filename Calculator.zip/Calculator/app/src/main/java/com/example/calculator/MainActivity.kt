package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Declare UI components
    private lateinit var etNum1: EditText
    private lateinit var etNum2: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnSub: Button
    private lateinit var btnMul: Button
    private lateinit var btnDiv: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views
        etNum1 = findViewById(R.id.et_number_1)
        etNum2 = findViewById(R.id.et_number_2)
        btnAdd = findViewById(R.id.btn_add)
        btnSub = findViewById(R.id.btn_sub)
        btnMul = findViewById(R.id.btn_mul)
        btnDiv = findViewById(R.id.btn_div)
        tvResult = findViewById(R.id.tv_result)

        // Set Click Listeners for each button
        btnAdd.setOnClickListener { calculate("+") }
        btnSub.setOnClickListener { calculate("-") }
        btnMul.setOnClickListener { calculate("*") }
        btnDiv.setOnClickListener { calculate("/") }
    }

    // A function to handle the math logic
    private fun calculate(operator: String) {
        // 1. Get the text from inputs
        val num1Str = etNum1.text.toString()
        val num2Str = etNum2.text.toString()

        // 2. Check if inputs are empty (prevent crash)
        if (num1Str.isNotEmpty() && num2Str.isNotEmpty()) {
            val num1 = num1Str.toDouble()
            val num2 = num2Str.toDouble()
            var result = 0.0

            // 3. Do the math
            when (operator) {
                "+" -> result = num1 + num2
                "-" -> result = num1 - num2
                "*" -> result = num1 * num2
                "/" -> {
                    if (num2 != 0.0) {
                        result = num1 / num2
                    } else {
                        tvResult.text = "Cannot divide by 0"
                        return // Stop here
                    }
                }
            }

            // 4. Show result
            tvResult.text = "Result: $result"
        } else {
            tvResult.text = "Please enter numbers"
        }
    }
}