package com.example.lab3

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// 1. Updated Data Class: Added 'category'
data class Formula(val name: String, val equation: String, val category: String)

class FormulaAdapter(
    // Changed 'val' to 'var' so we can swap out the list when filtering
    private var formulaList: List<Formula>,
    private val onItemClick: (Formula) -> Unit
) : RecyclerView.Adapter<FormulaAdapter.FormulaViewHolder>() {

    class FormulaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_formula_name)
        val tvEquation: TextView = itemView.findViewById(R.id.tv_formula_equation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FormulaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_formula, parent, false)
        return FormulaViewHolder(view)
    }

    override fun onBindViewHolder(holder: FormulaViewHolder, position: Int) {
        val currentFormula = formulaList[position]
        holder.tvName.text = currentFormula.name
        holder.tvEquation.text = currentFormula.equation

        holder.itemView.setOnClickListener { onItemClick(currentFormula) }
    }

    override fun getItemCount(): Int = formulaList.size

    // 2. NEW FUNCTION: This updates the RecyclerView when a category is clicked
    fun updateData(newFormulaList: List<Formula>) {
        this.formulaList = newFormulaList
        notifyDataSetChanged() // Tells Android to refresh the screen
    }
}