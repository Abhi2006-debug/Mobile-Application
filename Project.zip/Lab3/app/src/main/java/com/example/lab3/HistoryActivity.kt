package com.example.lab3

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val rvHistory = findViewById<RecyclerView>(R.id.rv_history)
        rvHistory.layoutManager = LinearLayoutManager(this)

        // 1. Open the database and get all logs
        val dbHelper = DatabaseHelper(this)
        val logs = dbHelper.getAllLogs()

        // 2. Check if it's empty
        if (logs.isEmpty()) {
            Toast.makeText(this, "No history found yet!", Toast.LENGTH_SHORT).show()
        }

        // 3. Attach the data to the RecyclerView
        val adapter = LogAdapter(logs)
        rvHistory.adapter = adapter
    }
}