package com.example.lab3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.asin
import kotlin.math.sin

class PhysicsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_physics)

        // 1. Link Views
        val etN1 = findViewById<EditText>(R.id.et_n1)
        val etTheta1 = findViewById<EditText>(R.id.et_theta1)
        val etN2 = findViewById<EditText>(R.id.et_n2)
        val btnCalc = findViewById<Button>(R.id.btn_calc_physics)
        val tvResult = findViewById<TextView>(R.id.tv_result_physics)
        val btnSearch = findViewById<Button>(R.id.btn_search_theory)

        // 2. Calculate Button Logic
        btnCalc.setOnClickListener {
            val n1Str = etN1.text.toString()
            val theta1Str = etTheta1.text.toString()
            val n2Str = etN2.text.toString()

            if (n1Str.isNotEmpty() && theta1Str.isNotEmpty() && n2Str.isNotEmpty()) {
                val n1 = n1Str.toDouble()
                val theta1Deg = theta1Str.toDouble()
                val n2 = n2Str.toDouble()

                // PHYSICS LOGIC:
                // Formula: sin(theta2) = (n1 * sin(theta1)) / n2

                // Step A: Convert Degree to Radian (Computer Math)
                val theta1Rad = Math.toRadians(theta1Deg)

                // Step B: Calculate sin(theta2)
                val sinTheta2 = (n1 * sin(theta1Rad)) / n2

                // Step C: Check validity (Sin cannot be > 1 or < -1)
                if (sinTheta2 >= -1.0 && sinTheta2 <= 1.0) {
                    // Step D: Inverse Sin (arcsin) to get radians
                    val theta2Rad = asin(sinTheta2)

                    // Step E: Convert back to Degrees for human reading
                    val theta2Deg = Math.toDegrees(theta2Rad)

                    // Step F: Format to 2 decimal places
                    tvResult.text = String.format("Refracted Angle: %.2f°", theta2Deg)
                } else {
                    tvResult.text = "Error: Total Internal Reflection"
                }

            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // 3. WEB INTENT (Higher End Feature)
        // This opens the browser to search for "Snell's Law Formula"
        btnSearch.setOnClickListener {
            val query = "Snell's Law Formula Physics"
            val uri = Uri.parse("https://www.google.com/search?q=$query")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
    }
}