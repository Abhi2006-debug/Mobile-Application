package com.example.lab3

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.sqrt

class QuadraticActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quadratic)

        // 1. Link Views
        val etA = findViewById<EditText>(R.id.et_a)
        val etB = findViewById<EditText>(R.id.et_b)
        val etC = findViewById<EditText>(R.id.et_c)
        val btnSolve = findViewById<Button>(R.id.btn_solve_quad)
        val tvResult = findViewById<TextView>(R.id.tv_result_quad)

        // 2. Logic
        btnSolve.setOnClickListener {
            // "toDoubleOrNull" is safer than "toDouble" -> prevents crashes on bad input
            val a = etA.text.toString().toDoubleOrNull()
            val b = etB.text.toString().toDoubleOrNull()
            val c = etC.text.toString().toDoubleOrNull()

            // VALIDATION: Check if inputs are actually numbers
            if (a != null && b != null && c != null) {

                // CASE 1: Linear Equation (a = 0)
                // The equation becomes bx + c = 0
                if (a == 0.0) {
                    if (b != 0.0) {
                        val root = -c / b
                        tvResult.text = "This is a Linear Equation (a=0)\nRoot: %.2f".format(root)
                    } else {
                        tvResult.text = "Invalid Equation (a and b cannot both be 0)"
                    }
                    return@setOnClickListener
                }

                // CASE 2: Quadratic Equation
                val discriminant = (b * b) - (4 * a * c)

                if (discriminant > 0) {
                    // Two Real Roots
                    val root1 = (-b + sqrt(discriminant)) / (2 * a)
                    val root2 = (-b - sqrt(discriminant)) / (2 * a)
                    tvResult.text = "Two Real Roots:\nx₁ = %.2f\nx₂ = %.2f".format(root1, root2)

                } else if (discriminant == 0.0) {
                    // One Real Root (Repeated)
                    val root = -b / (2 * a)
                    tvResult.text = "One Real Root:\nx = %.2f".format(root)

                } else {
                    // Complex Roots (D < 0)
                    // Format: x = Real ± Imaginary i
                    val realPart = -b / (2 * a)
                    val imaginaryPart = sqrt(abs(discriminant)) / (2 * a) // abs() ensures positive sqrt

                    // Improved Formatting for Complex Numbers
                    // logic: if real part is effectively 0, don't show "0.00 +/- ..."
                    val realStr = if (abs(realPart) < 1e-10) "" else "%.2f".format(realPart)
                    val sign = if (abs(realPart) < 1e-10) "±" else " ± "

                    tvResult.text = "Complex Roots:\nx = %s%s%.2fi".format(realStr, sign, abs(imaginaryPart))
                }

            } else {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            }
        }
    }
}