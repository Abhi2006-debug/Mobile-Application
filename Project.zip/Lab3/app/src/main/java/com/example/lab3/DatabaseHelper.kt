package com.example.lab3

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Data class to hold our log information
data class LogItem(val id: Int, val action: String, val details: String, val timestamp: String)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "MathEnvDB.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_LOGS = "activity_logs"
        const val COLUMN_ID = "id"
        const val COLUMN_ACTION = "action_type"
        const val COLUMN_DETAILS = "details"
        const val COLUMN_TIME = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE $TABLE_LOGS ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "$COLUMN_ACTION TEXT,"
                + "$COLUMN_DETAILS TEXT,"
                + "$COLUMN_TIME DATETIME DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_LOGS")
        onCreate(db)
    }

    // Function to INSERT data
    fun insertLog(actionType: String, details: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUMN_ACTION, actionType)
        contentValues.put(COLUMN_DETAILS, details)
        val result = db.insert(TABLE_LOGS, null, contentValues)
        db.close()
        return result != -1L
    }

    // NEW: Function to READ data (Latest items first)
    @SuppressLint("Range")
    fun getAllLogs(): List<LogItem> {
        val logList = mutableListOf<LogItem>()
        val db = this.readableDatabase
        // Order by ID DESC puts the newest actions at the top of the list!
        val cursor = db.rawQuery("SELECT * FROM $TABLE_LOGS ORDER BY $COLUMN_ID DESC", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID))
                val action = cursor.getString(cursor.getColumnIndex(COLUMN_ACTION))
                val details = cursor.getString(cursor.getColumnIndex(COLUMN_DETAILS))
                val timestamp = cursor.getString(cursor.getColumnIndex(COLUMN_TIME))

                logList.add(LogItem(id, action, details, timestamp))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return logList
    }
}