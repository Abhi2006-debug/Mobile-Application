package com.example.lab3 // Make sure this matches your package name!

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FormulaDashboardActivity : AppCompatActivity() {

    // 1. Your Master List of Formulas
    private val allFormulas = listOf(
        Formula("Quadratic Formula", "x = [-b ± √(b² - 4ac)] / 2a", "Algebra"),
        Formula("Linear Equation", "y = mx + b", "Algebra"),
        Formula("Newton's Second Law", "F = ma", "Physics"),
        Formula("Einstein's Mass-Energy", "E = mc²", "Physics"),
        Formula("Ohm's Law", "V = IR", "Physics"),
        Formula("Pythagorean Theorem", "a² + b² = c²", "Geometry"),
        Formula("Area of a Circle", "A = πr²", "Geometry")
    )

    private lateinit var formulaAdapter: FormulaAdapter
    private lateinit var tvListTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formula_dashboard)

        tvListTitle = findViewById(R.id.tv_list_title)

        // 2. SETUP RECYCLER VIEW
        val recyclerView = findViewById<RecyclerView>(R.id.rv_formula_list)
        recyclerView.layoutManager = LinearLayoutManager(this)

        formulaAdapter = FormulaAdapter(allFormulas) { clickedFormula ->
            // NEW: Save to Database when a specific formula is clicked!
            val db = DatabaseHelper(this)
            db.insertLog("Formula Reference", "Viewed formula: ${clickedFormula.name}")

            Toast.makeText(this, "Selected: ${clickedFormula.name}", Toast.LENGTH_SHORT).show()
        }
        recyclerView.adapter = formulaAdapter

        // 3. HORIZONTAL CARDS LOGIC (Filtering)
        findViewById<CardView>(R.id.card_algebra).setOnClickListener {
            logCategoryClick("Algebra")
            filterFormulas("Algebra")
        }
        findViewById<CardView>(R.id.card_physics).setOnClickListener {
            logCategoryClick("Physics")
            filterFormulas("Physics")
        }
        findViewById<CardView>(R.id.card_geometry).setOnClickListener {
            logCategoryClick("Geometry")
            filterFormulas("Geometry")
        }

        // 4. FAB LOGIC
        findViewById<FloatingActionButton>(R.id.fab_add_item).setOnClickListener {
            showAddFormulaActionBox()
        }
    }

    // ==========================================
    // HELPER FUNCTIONS
    // ==========================================

    // NEW: Function to log category clicks to the database
    private fun logCategoryClick(category: String) {
        val db = DatabaseHelper(this)
        db.insertLog("Formula Reference", "Filtered by category: $category")
    }

    private fun filterFormulas(category: String) {
        val filteredList = allFormulas.filter { it.category == category }
        formulaAdapter.updateData(filteredList)
        tvListTitle.text = "$category Formulas"
    }

    // Action Box / AlertDialog
    private fun showAddFormulaActionBox() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add New Formula")
        builder.setMessage("Open the editor to create a new custom formula?")

        builder.setPositiveButton("Yes, Create") { dialog, _ ->
            // NEW: Save to Database when they click 'Yes' to add a formula!
            val db = DatabaseHelper(this)
            db.insertLog("Formula Reference", "Opened Add Formula Editor")

            Toast.makeText(this, "Opening Editor...", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }
}