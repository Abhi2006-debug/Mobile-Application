package com.example.lab3

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class VectorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vector)

        // Link Inputs
        val ax = findViewById<EditText>(R.id.et_ax)
        val ay = findViewById<EditText>(R.id.et_ay)
        val az = findViewById<EditText>(R.id.et_az)
        val bx = findViewById<EditText>(R.id.et_bx)
        val by = findViewById<EditText>(R.id.et_by)
        val bz = findViewById<EditText>(R.id.et_bz)

        val btnDot = findViewById<Button>(R.id.btn_dot)
        val btnCross = findViewById<Button>(R.id.btn_cross)
        val tvResult = findViewById<TextView>(R.id.tv_result_vec)

        // DOT PRODUCT LOGIC
        btnDot.setOnClickListener {
            if (validate(ax, ay, az, bx, by, bz)) {
                val aX = ax.text.toString().toDouble()
                val aY = ay.text.toString().toDouble()
                val aZ = az.text.toString().toDouble()
                val bX = bx.text.toString().toDouble()
                val bY = by.text.toString().toDouble()
                val bZ = bz.text.toString().toDouble()

                // Dot Product = (ax*bx) + (ay*by) + (az*bz)
                val dotProduct = (aX * bX) + (aY * bY) + (aZ * bZ)
                tvResult.text = "Dot Product Result:\n$dotProduct"
            }
        }

        // CROSS PRODUCT LOGIC
        btnCross.setOnClickListener {
            if (validate(ax, ay, az, bx, by, bz)) {
                val aX = ax.text.toString().toDouble()
                val aY = ay.text.toString().toDouble()
                val aZ = az.text.toString().toDouble()
                val bX = bx.text.toString().toDouble()
                val bY = by.text.toString().toDouble()
                val bZ = bz.text.toString().toDouble()

                // Cross Product Formula (Determinant method)
                val cX = (aY * bZ) - (aZ * bY)
                val cY = (aZ * bX) - (aX * bZ)
                val cZ = (aX * bY) - (aY * bX)

                tvResult.text = "Cross Product Result:\n( $cX ) i + ( $cY ) j + ( $cZ ) k"
            }
        }
    }

    // Helper to check if inputs are empty
    private fun validate(vararg edits: EditText): Boolean {
        for (et in edits) {
            if (et.text.isEmpty()) {
                Toast.makeText(this, "Please fill all fields (use 0 for empty)", Toast.LENGTH_SHORT).show()
                return false
            }
        }
        return true
    }
}