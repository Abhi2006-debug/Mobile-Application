package com.example.lab3

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class graph_plotter : AppCompatActivity() {

    // Store the current graph so we can access it from the Zoom Buttons
    private var currentGraphView: BasicGraphView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_graph_plotter)

        val rootView = findViewById<View>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(insets.left, insets.top, insets.right, insets.bottom)
            windowInsets
        }

        val btnPlot = findViewById<Button>(R.id.btn_plot)
        val etFunction = findViewById<EditText>(R.id.et_function)
        val etXMin = findViewById<EditText>(R.id.et_x_min)
        val etXMax = findViewById<EditText>(R.id.et_x_max)
        val graphContainer = findViewById<FrameLayout>(R.id.graph_container)
        val tvPlaceholder = findViewById<TextView>(R.id.tv_graph_placeholder)

        val zoomControls = findViewById<LinearLayout>(R.id.zoom_controls)
        val btnZoomIn = findViewById<TextView>(R.id.btn_zoom_in)
        val btnZoomOut = findViewById<TextView>(R.id.btn_zoom_out)

        btnPlot.setOnClickListener {
            val functionText = etFunction.text.toString().lowercase()
            val minX = etXMin.text.toString().toFloatOrNull() ?: -10f
            val maxX = etXMax.text.toString().toFloatOrNull() ?: 10f

            if (minX >= maxX) {
                Toast.makeText(this, "Min X must be smaller than Max X", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            tvPlaceholder.visibility = View.GONE
            zoomControls.visibility = View.VISIBLE // Show zoom buttons!

            // Remove old graph if it exists
            currentGraphView?.let { graphContainer.removeView(it) }

            // Create new graph and add it to the container
            currentGraphView = BasicGraphView(this, minX, maxX, functionText)

            // Add the graph to the layout (at index 0 so it stays UNDER the zoom buttons)
            graphContainer.addView(currentGraphView, 0)
        }

        // Hook up the Zoom Buttons
        btnZoomIn.setOnClickListener {
            currentGraphView?.zoomIn()
        }

        btnZoomOut.setOnClickListener {
            currentGraphView?.zoomOut()
        }
        // Inside graph_plotter.kt onCreate()

        btnPlot.setOnClickListener {
            val functionText = etFunction.text.toString().lowercase()
            val minX = etXMin.text.toString().toFloatOrNull() ?: -10f
            val maxX = etXMax.text.toString().toFloatOrNull() ?: 10f

            if (minX >= maxX) {
                Toast.makeText(this, "Min X must be smaller than Max X", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // NEW: Save the math calculation to the Database!
            val db = DatabaseHelper(this)
            db.insertLog("Graph Plotter", "Plotted function: f(x)=$functionText from $minX to $maxX")

            tvPlaceholder.visibility = View.GONE
            zoomControls.visibility = View.VISIBLE

            currentGraphView?.let { graphContainer.removeView(it) }
            currentGraphView = BasicGraphView(this, minX, maxX, functionText)
            graphContainer.addView(currentGraphView, 0)
        }
    }

    // ========================================================
    // UPGRADED CUSTOM VIEW WITH PINCH-TO-ZOOM
    // ========================================================
    @SuppressLint("ViewConstructor")
    private inner class BasicGraphView(
        context: Context,
        private val originalMinX: Float,
        private val originalMaxX: Float,
        private val function: String
    ) : View(context) {

        // The master zoom variable
        private var scaleFactor = 1.0f

        // 1. PINCH DETECTOR LOGIC
        private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleFactor *= detector.scaleFactor
                // Keep the zoom from getting too crazy (limit from 0.1x to 20x zoom)
                scaleFactor = scaleFactor.coerceIn(0.1f, 20.0f)
                invalidate() // Redraw the graph immediately!
                return true
            }
        })

        // Catch screen touches and pass them to our scale detector
        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            scaleDetector.onTouchEvent(event)
            return true
        }

        // Functions for our physical buttons
        fun zoomIn() {
            scaleFactor = (scaleFactor * 1.5f).coerceAtMost(20.0f)
            invalidate()
        }

        fun zoomOut() {
            scaleFactor = (scaleFactor / 1.5f).coerceAtLeast(0.1f)
            invalidate()
        }

        private val axisPaint = Paint().apply {
            color = Color.parseColor("#546E7A")
            strokeWidth = 3f
        }

        private val linePaint = Paint().apply {
            color = Color.parseColor("#E64A19")
            strokeWidth = 6f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val screenWidth = width.toFloat()
            val screenHeight = height.toFloat()

            // 2. MATHEMATICAL ZOOM LOGIC
            // Instead of scaling the pixels (which makes lines thick/blurry),
            // we shrink or expand the mathematical "window" we are looking at!
            val centerX = (originalMinX + originalMaxX) / 2f
            val spanX = (originalMaxX - originalMinX) / scaleFactor
            val minX = centerX - spanX / 2f
            val maxX = centerX + spanX / 2f

            val centerY = 0f
            val spanY = 200f / scaleFactor // Default base Y range is 200 (-100 to 100)
            val minY = centerY - spanY / 2f
            val maxY = centerY + spanY / 2f

            // Draw Y-Axis (Vertical Line)
            val zeroX = screenWidth * (0 - minX) / (maxX - minX)
            canvas.drawLine(zeroX, 0f, zeroX, screenHeight, axisPaint)

            // Draw X-Axis (Horizontal Line)
            val zeroY = screenHeight - (screenHeight * (0 - minY) / (maxY - minY))
            canvas.drawLine(0f, zeroY, screenWidth, zeroY, axisPaint)

            var prevScreenX = -1f
            var prevScreenY = -1f
            val pointsToDraw = 150 // Increased slightly for smoother zoomed-in curves

            // Plot the points!
            for (i in 0..pointsToDraw) {
                val currentX = minX + (maxX - minX) * (i.toFloat() / pointsToDraw)

                var currentY = 0f
                if (function.contains("x^2")) {
                    currentY = currentX * currentX
                } else if (function.contains("x")) {
                    currentY = currentX
                }

                val screenX = screenWidth * (currentX - minX) / (maxX - minX)
                val screenY = screenHeight - (screenHeight * (currentY - minY) / (maxY - minY))

                if (i > 0) {
                    canvas.drawLine(prevScreenX, prevScreenY, screenX, screenY, linePaint)
                }
                prevScreenX = screenX
                prevScreenY = screenY
            }
        }
    }
}